---
name: rough-cut
description: Step 1 for talking footage — take a raw take (talking head, screen recording with voice) and produce a tight cut with no silences, bad takes, false starts or filler, clean audio, a word-level transcript, old burned-in subtitles removed, and the strongest hook copied to the front. Use when the person drops in a raw clip, says "new video", "start a project", "rough cut", "cut this", "pick the hook", or adjusts the cut ("you clipped that word", "remove that sentence").
---

# Rough cut

Goal: `work/cut.mp4` (tight, clean audio, hook first), `work/cut.words.json` (its transcript, corrected), `work/cut-segments.json` (the kept ranges, for punch-ins and transitions later), `work/script.md` (what is said, as kept). Lock it with the person before graphics.

## 1. Intake
- New footage: `python scripts/vid.py new <preset> <slug> <file>…` (preset from `presets/formats.md`; infer it, ask only if truly unclear). It prints the job name.
- YouTube link instead of a file: `python scripts/yt_download.py "<url>" -q 1080` (add `--start`/`--end` to grab only a section). It saves an MP4 to `inbox/` and prints the path; pass that file to `vid.py new`. Extraction error → `python -m pip install -U yt-dlp` and retry.
- **Label each raw file's role in `job.md`** (main take · B-roll · music · other). B-roll = no one talking to camera, or the person says so. Only main takes are transcribed and cut; B-roll waits for `/graphics`.
- Several raw takes of the same content: transcribe each and pick across them (best take per sentence), cutting from each file, then join with `ffmpeg -f concat`.
- Footage that is only generated clips playing clean (avatar shots, AI scenes) → not a rough-cut job: use `/assemble`.

## 2. Old subtitles (camera or AI footage only — skip screen recordings, they are full of text)
```bash
python scripts/vid.py subs projects/<job>/raw/<file>
```
- It reports soft subtitle tracks and any burned-in text band, and writes a contact sheet with a pixel ruler. **Look at the sheet before deciding** — the detector flags any dense text (a sign, a T-shirt print), not only subtitles.
- No subtitles → note "Burned-in subtitles: none" in `job.md`, use the raw file as the source below.
- Subtitles present → tell the person in one line and use the default unless they object:
  - **black** (default): `python scripts/vid.py mask <raw file> --scan <work/…subs.json>` — the black band becomes the background of our own captions in `/captions`, so it reads as one deliberate style.
  - **crop**, preferred when the band is near the bottom/top edge and the push-in is ≤ 1.3× (the command warns above 1.35×): `--mode crop`. Check one frame that the face isn't cut.
  - **blur**: `--mode blur` (softer, old text can stay faintly readable).
  - 9:16 note: if the band is below 1330 px (the scan says `inside 9:16 safe zone: False`), our captions in that band will sit under the TikTok/Reels UI — mention it and offer crop.
- Record in `job.md`: `Burned-in subtitles: yes — band y=Y0–Y1 px, mode black, during <times or whole clip>, captions centre y≈…` (the mask command prints the centre). Use `work/<file>-nosubs.mp4` as the source for steps 3–5. Only soft tracks → `python scripts/vid.py mask <file>` strips them, picture untouched.

## 3. Transcribe the source (once)
Use the HyperFrames media-use transcriber, which writes word timestamps to a file you name:

```bash
node .claude/skills/media-use/scripts/transcribe.mjs --input <source> --out projects/<job>/work/raw.words.json
```
It uses Parakeet when installed (English + French + 23 more), else whisper. For whisper on French speech, run `npx hyperframes transcribe <file> --model small --language fr --json` instead and move the JSON it names into `work/raw.words.json`. Never an `.en` model on non-English speech.

Then read it the readable way — never the raw JSON:
```bash
python scripts/words.py show projects/<job>/work/raw.words.json
```

## 4. Decide the cut (this is the editing judgment)
Read the whole numbered transcript and write `work/cut-plan.md`:

- **Bad takes / repeats:** when a sentence is said several times, keep the **last complete, fluent** version; remove the earlier attempts entirely (from their first word to their last).
- **False starts and self-corrections:** "So the — so the first step" → keep "so the first step".
- **Off-script talk:** "ok let me redo that", "wait", counting in, talking to someone off camera, reading the prompt aloud before the take.
- **Fillers:** um, uh, euh, erm; "like / you know / basically / so" only when they are filler, not meaning.
- **Silences:** handled by `--cut-silence` (0.5 s for 9:16 presets, 0.7 s for `lesson`). Keep a natural breath between ideas in lessons.
- Keep the person's meaning and order; don't rewrite what they say. If a sentence is broken in every take, keep the best one and flag it.

`cut-plan.md` = the kept script as clean text (this becomes `script.md`), then a removal table: word range · text removed · reason.

## 5. Cut
Convert the word ranges into padded time ranges (keeps ~80 ms of air so no kept word gets clipped):
```bash
python scripts/words.py ranges projects/<job>/work/raw.words.json "12-18,40-41,…"
```
Plan first — **save the plan, later steps need it** — then encode:
```bash
node .claude/skills/media-use/scripts/transcript-cut.mjs \
  --input <source> --transcript projects/<job>/work/raw.words.json \
  --remove "<time ranges from words.py>" --remove-fillers "um,uh,erm,euh" --cut-silence 0.5 \
  --plan > projects/<job>/work/cut-segments.json
# check the kept segments make sense, then the same command with --out projects/<job>/work/cut.raw.mp4 instead of --plan
```

## 6. Polish the audio, transcribe the cut, fix names
```bash
python scripts/vid.py polish projects/<job>/work/cut.raw.mp4 projects/<job>/work/cut.mp4
node .claude/skills/media-use/scripts/transcribe.mjs --input projects/<job>/work/cut.mp4 --out projects/<job>/work/cut.words.json
python scripts/words.py fix projects/<job>/work/cut.words.json brand/caption-corrections.json
```
(Noisy room: `--denoise 18`; already clean: `--denoise 0`.) Read `words.py show` on the cut: no repeated sentence, no stray filler, no half word at a cut. Write the clean text to `work/script.md`.

## 7. Hook first (cold open)
Default **on** for `short-explainer` and `short-raw`; for `lesson`, offer it once (good for YouTube, rarely for course modules); `ugc-ad` gets its hook from the script in `/assemble`.

1. From `cut.words.json`, propose **3 hook candidates**, best first, each with its times and exact words. A good hook:
   - is 1–4 s and a complete phrase that makes sense with zero context (no "this/that" pointing at something earlier);
   - is a bold result, a surprising claim, a curiosity gap, or a sharp question — the line that makes someone stop scrolling;
   - is never the greeting, the CTA, or a claim stronger than what the video actually shows.
2. The person picks (autopilot: take #1). Then, with exact word times (start a hair before the first word, end just after the last):
```bash
python scripts/vid.py coldopen projects/<job>/work/cut.mp4 --start A --end B --flash \
  --words projects/<job>/work/cut.words.json --words-out projects/<job>/work/cut-hook.words.json \
  --out projects/<job>/work/cut-hook.mp4
```
   `--flash` bakes a quick white "zap" at the seam (default for 9:16; drop it for a plain cut). The hook still plays in its original place — that's intended.
3. Make the hook version the current cut: rename `cut.mp4` → `cut-nohook.mp4`, `cut-hook.mp4` → `cut.mp4`, and the same for the words files. No re-transcription — the words were shifted.
4. Log in `job.md`: `Hook (cold open): "<words>" from A–B, length H s, seam at H s, flash: yes/no`. Later steps add H as `--offset` to cut points.

## 8. Show and lock
- `python scripts/vid.py open projects/<job>/work/cut.mp4` and tell the person the before → after length, the hook chosen, and anything you weren't sure about (one line each).
- Adjustments ("you cut 'can' too close", "remove 'basically' at 0:23", "use the other hook") → change the removal list and re-run from step 5 (or redo only step 7 from `cut-nohook.mp4` for a hook change). For a too-tight cut, raise `--pad` in `words.py ranges` to 0.15 for that range.
- When the person says it's good: tick step 1 in `job.md`, log the decisions, and suggest `/graphics` (which also places B-roll, punch-ins and transitions). Tell them a new chat is fine from here — `job.md` carries the context.
