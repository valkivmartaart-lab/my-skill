---
name: graphics
description: Step 2 — plan and build everything visual over a locked cut with HyperFrames — hook and title cards, lower thirds, key-point cards, lists, stats, logos, callouts, B-roll cutaways from clips the person provides, punch-ins on jump cuts, and transitions at the hook seam and section breaks — then iterate on the person's notes ("move this down", "make it orange", "add the logo"). Use when the person says "graphics", "do the graphics", "add cards/visuals/motion", "add this B-roll", "add transitions", or gives feedback on a graphic.
---

# Graphics

Read `job.md` (preset, hook seam, B-roll files, subtitle band), the preset in `presets/formats.md`, `brand/brand.md`, and `work/script.md`. The cut must be locked (step 1 ticked) — if not, say so first.

## 1. Set up the composition (first time only)
For a rough-cut job, `comp/` is still empty:
```bash
cd projects/<job>/comp && npx hyperframes init . --video ../work/cut.mp4 --resolution <landscape|portrait> --non-interactive --skip-transcribe
```
(Skip for `/assemble` jobs — `comp/` is already built.) Copy the brand logo and any custom font from `brand/assets/` into `comp/assets/`. Put brand colours and fonts as CSS variables on the root so every card uses them. Clamp the root `data-duration` to the footage's ffprobe length. Keep the main footage inside one wrapper element (`#footage`) so punch-ins scale it as a whole.

## 2. Gather what the plan needs
- **Cut points** (rough-cut jobs): exact join times in the current cut, snapped to real frames:
  ```bash
  python scripts/vid.py cutpoints projects/<job>/work/cut-segments.json --video projects/<job>/work/cut.mp4 [--offset <hook length from job.md>]
  ```
  With a cold open, the first cut is the hook seam (exact, not snapped).
- **B-roll** (files marked B-roll in `job.md`, or a path the person gives now — copy new ones into `raw/` and note them): for each,
  ```bash
  python scripts/vid.py subs <broll>     # mask old subtitles first if any (same rules as /rough-cut step 2)
  python scripts/vid.py scenes <broll>   # shot list + contact sheet
  ```
  Look at the contact sheet: you match shots to the script by what they show, so you need to see them. For `ugc-ad`, grade B-roll with `vid.py grade` like the other footage.
- **Stock footage (Pixabay) — only when the person asks for it** ("add stock footage", "cover the slides with B-roll", "put a clip of X over this"). Never add it on your own initiative, not even in autopilot; at most mention once that a stretch (slides, no face, a soft wide shot) could be covered if they want.
  ```bash
  python scripts/vid.py stock search <2–4 concrete words> --job <job> [--photo] [--orientation horizontal|vertical] [--min 3]
  python scripts/vid.py stock get <n> --job <job>     # → raw/stock/, source logged in work/stock-sources.txt
  ```
  Search with what is literally visible ("goalkeeper catching ball", not "persistence"). Look at the numbered preview sheet (`work/stock-search.jpg` in the job) before choosing; `stock open <n> --job <job>` shows the page. Results are stored per job, so parallel jobs never mix them up. Then treat the clip like any other B-roll (`scenes`, rules below), add it to `job.md` under Raw files as role B-roll, and list in the plan exactly where each stock clip goes and why. Photos: hold 2–3 s with a slow push-in. Pixabay Content License: free for commercial use, no credit needed.

## 3. Plan the beats — and get a yes before building
Read `python scripts/words.py show work/cut.words.json` and write `work/graphics-plan.md`, one row per beat:

| # | In–out | Type | Content | Zone |
|---|---|---|---|---|
| 1 | 0.0–2.5 | hook card | "3 edits that save me an hour a day" | top band |
| 2 | 4.1–9.0 | key-point card | "Cut the silences first" | side panel |
| 3 | 9.4–12.1 | B-roll | broll_phone.mp4 shot #2 (3.0–5.7 s), full frame, muted | full |
| 4 | 12.1 | transition | flash (section break: "step two") | — |

Types: hook/title card · lower third · key-point card · numbered list · stat/number · before-after · tool logo strip · flowchart · callout/arrow on a screen recording · punch-in · B-roll · transition · chapter card · CTA/end card. Timing comes from the words (a card appears on the word it illustrates); density and zones from the preset. Prefer real assets — the tool's real logo, the real app screen — over drawn imitations.

**B-roll rules** (rows in the same table):
- Place a shot where the words describe what it shows ("I open the app" → the app screen). No match in meaning → don't force it; list unused shots under the table.
- 1.5–4 s each, starting and ending on word boundaries; the voice keeps playing underneath; B-roll muted unless the person wants its sound.
- Never cover the hook's first 1.5 s or the CTA (the face sells those), never two cutaways back to back for more than 6 s, at most ~40 % of the runtime under B-roll.
- Layout: 9:16 → full frame, or top half with the face kept in the bottom half (`short-explainer`); 16:9 → full frame or picture-in-picture (`references/overlays.md`). Different aspect → `object-fit: cover` and choose the focus point; never stretch.

**Cuts and transitions** (defaults per preset in `presets/formats.md`):
- **Punch-ins on jump cuts** (9:16 presets): at each cut point from step 2, alternate the footage scale 1.00 ↔ 1.12 (instant, no tween, centred on the face), so jump cuts read as deliberate. Skip a cut when the previous one is < 1.2 s earlier, and don't punch in under a card that already frames the face.
- **Transitions**: only at the hook seam (if `job.md` says the flash is already baked, add nothing there) and at real section breaks (a new step, a chapter, before the CTA) — never on every cut, that is what makes AI edits look cheap. One style per video, from the registry: `npx hyperframes catalog --tag transition --json` (flash, whip, glitch/zap, zoom…), installed with `npx hyperframes add <name>`. 0.2–0.4 s, at most one every ~10 s.

Send the plan as a short table and wait for "go" (a 2-minute read saves a 20-minute wrong build) — unless the person asked for no stops.

## 4. Build
Follow `/hyperframes` (read `references/overlays.md` for cards over a talking head, `references/motion.md` for punch-ins and cuts, and `references/types/vertical.md` for 9:16). Before hand-writing a card style or transition, look in the registry: `npx hyperframes catalog --json` (`/hyperframes-registry`). One sub-composition per beat or chapter, stable short ids (`#hook`, `#kp-03`, `#broll-02`), copy and colours as variables so the person can edit them in Studio.

- B-roll: copy the clip into `comp/assets/broll/`, one `<video class="clip" muted>` per cutaway with `data-media-start` (the shot's in-point) + `data-start` + `data-duration`, above `#footage` by `z-index`; time the video or its wrapper, never both. Footage with keyframes > 1 s apart freezes on seek — re-encode with `-g 30` first.
- Punch-ins: `tl.set("#footage", { scale: 1.12 }, t)` / `tl.set("#footage", { scale: 1 }, t2)` on the footage wrapper, `transform-origin` on the face.

Then: `npx hyperframes check --json` (fix every error) → `npx hyperframes snapshot` at each beat's midpoint and on both sides of each transition, and look at the PNGs (face never covered, text inside the safe band, nothing cut off, B-roll framed well) → `npx hyperframes preview --background`, verify the URL answers 200, give it to the person.

## 5. Second pass (the person's notes)
- The person can **click an element in the preview** and say "this one": read it with `npx hyperframes preview --context --json --context-fields selection` instead of guessing from a description.
- Several notes in one message: do them all, then one check + snapshot of what changed (`--at <t>` / `--composition <id>`), not the whole video.
- They may edit directly in the preview/HyperFrames desktop app too: at the start of each turn, `npx hyperframes history --since mine --who claude` and build on their changes, never overwrite them.
- A style decision that should stick for future videos ("always put lower thirds bottom-left", "this orange", "whip transitions") → offer to add it to `brand/brand.md` or `presets/formats.md`.

When the person is happy: tick step 2 in `job.md` with a one-line summary of the look (and which B-roll shots were used); suggest `/captions` (9:16) or `/finish` (lesson).
