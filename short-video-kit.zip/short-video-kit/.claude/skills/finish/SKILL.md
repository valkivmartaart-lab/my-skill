---
name: finish
description: Step 4 — find or add background music (search the free Jamendo library, use a file, or generate), duck it under the voice, balance loudness, render the final MP4, and export to outputs/ and Downloads with the music credit and a same-named .md post copy (Instagram/TikTok caption, YouTube title + description). Use when the person says "add music", "find music", "something chill", "finish", "render", "export", "we're done", or adjusts the music level.
---

# Finish

Read `job.md` and the preset's music/finish rows in `presets/formats.md`.

## 1. Music (optional)
Three sources, in this order of preference:
- **A file the person gives** (or one already in `music/`, e.g. from Pixabay Music — no API, downloaded by hand, no credit needed) → copy it to `comp/assets/music/`.
- **Search Jamendo** when they ask you to find music ("find something chill and instrumental"):
  ```bash
  python scripts/vid.py music search [free words] --tags chill,lofi --instrumental --min <video length> --max 300
  ```
  Turn the mood into 1–3 tags (genre + mood: `lofi,chill`, `corporate,upbeat`, `cinematic,epic`, `electronic,energetic`); `--speed low|medium|high|veryhigh` for pace; `--min` ≥ the video length so it doesn't loop. Show the person the list as returned (title, length, license) and let them listen: `python scripts/vid.py music open <n>` opens the track page. Then `python scripts/vid.py music get <n> --job <job>` downloads it into the job and records the credit line.
  - First time: no client ID → it prints how to get a free one (devportal.jamendo.com → create an app → Client ID). Ask the person for it and save it with `python scripts/vid.py config set jamendo_client_id <ID>` (stored only in `config.local.json`, never shared).
  - Licenses: non-commercial tracks are hidden by default — keep it that way for ads and anything promoting a paid product; `--allow-nc` only if the person says the video is non-commercial. Nearly all Jamendo tracks require a credit: `finalize` puts it next to the video and prints it; remind the person to paste it into the post description.
- **Generate** with `/media-use` (`npx hyperframes media-use resolve --type bgm --intent "<mood>"`) as a fallback.
Only royalty-free or licensed tracks, never a commercial song.
- Add it as `<audio id="bgm">` in `index.html` across the video (trim to length, 1 s fade-out at the end).
- Duck it under the voice: `audio-duck.mjs` from `/media-use` (`references/operations.md` → Ducking) writes a `data-automation` volume lane on `#bgm`.
- Level: start at the preset's value (−20 to −24 dB under the voice; lessons −28 dB or none). The person judges by ear — when they settle on a value ("−23 is perfect"), log it in `job.md` and offer to make it the preset default.
- Balance: `npx hyperframes normalize-audio --lufs=-16 --write` (voice at −16 LUFS for social and YouTube).

## 2. Final check, then render
`npx hyperframes check --json` with zero errors, then:
```bash
cd projects/<job>/comp && npx hyperframes render --quality delivery --output ../work/<job>.render.mp4
```
Add `--fps 60` only for `ugc-ad` going to Meta if the person said yes. Confirm the file is non-empty, its ffprobe duration matches the root `data-duration`, and look at 3 decoded frames (start, middle, end): `ffmpeg -ss <t> -i … -frames:v 1 projects/<job>/work/frame-<t>.png`.

(The `ugc-ad` realism grade was already applied to the footage in `/assemble`. If a finished video from elsewhere needs it as a whole, `python scripts/vid.py grade <file> --deliver`.)

## 3. Post copy (every final video, no exceptions)
Before exporting, write `projects/<job>/work/post.md` — the person posts with it, so it ships with the video:

```markdown
# <job>

## Instagram & TikTok caption
<hook line that makes people stop — not the video's first sentence verbatim>
<2–4 short lines: the takeaway, concrete, in the brand tone>
<one question or CTA that invites comments/saves>

#tag1 #tag2 … (5–8 relevant hashtags, mix of broad and niche)

## YouTube
**Title:** <≤ 70 characters, curiosity + keyword, no clickbait the video doesn't pay off> #Shorts (for 9:16)

**Description:**
<2–3 sentences on what the viewer learns>
<credit line for the speaker/source when the footage isn't the person's own, e.g. "Clip: <speaker>, <event or channel>">
<music credit from music-credits.txt when there is one>

#hashtag1 #hashtag2 #hashtag3
```
- Write it from `work/script.md` / the cut transcript: only claims the video actually makes, numbers as said, no result or income promises (see `brand/brand.md`).
- Language = the video's language.
- A `lesson` (16:9, long-form) still gets the file: YouTube title + description matter most; keep the Instagram/TikTok section for a teaser.

## 4. Export
```bash
python scripts/vid.py finalize <job> projects/<job>/work/<job>.render.mp4 --expect-seconds <root data-duration> [--srt projects/<job>/work/<job>.srt] [--to "<folder the person wants it in>"]
```
It copies to `outputs/<job>.final.mp4` and the Downloads folder (plus `<job>.credits.txt` when a Jamendo track was used), and logs the export in `job.md`. **It copies `work/post.md` as `<job>.final.md` next to every copy of the video** (outputs, Downloads and each `--to` folder) and refuses to run without it. If the person asks for the video somewhere else, pass that folder with `--to` rather than copying by hand, so the `.md` always sits beside the `.mp4` under the same name. The project stays intact for later edits.

Tell the person where it is (one line) and, for social presets, the posting notes: tick the platform's AI-generated content label for avatar/AI footage; first frame = the hook. Offer `python scripts/vid.py prune <job>` only if disk space comes up.

Tick step 4 in `job.md`.
