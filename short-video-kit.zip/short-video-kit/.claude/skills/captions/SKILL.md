---
name: captions
description: Step 3 — add animated burned-in captions from the existing transcript (9:16 presets), placed over the black band when old subtitles were covered, or an SRT subtitle file for lessons/YouTube. Use when the person says "captions", "subtitles", "add captions", "replace the subtitles", or gives caption feedback (size, position, style, a misspelled word).
---

# Captions

No re-transcription: captions come from `work/cut.words.json` (already corrected by `words.py fix`). Read `job.md` and the preset's caption row in `presets/formats.md`.

## Lesson / long-form (16:9)
No burned-in captions by default. Write the sidecar and stop:
```bash
python scripts/words.py srt projects/<job>/work/cut.words.json projects/<job>/work/<job>.srt
```
`/finish` copies it next to the MP4. Burn them in only if the person asks.

## 9:16 presets
1. Re-read the words once for errors a viewer would notice (brand names, numbers written as words → digits, "gonna" is fine). Fix in the JSON; add recurring mistakes to `brand/caption-corrections.json`.
2. Pick the style: `npx hyperframes catalog --tag caption-style --json` and choose the closest to the preset (`short-explainer`: centred, locked, active-word highlight in the brand accent · `short-raw`: low under the face, 2–3 words, punchy · `ugc-ad`: TikTok-native, bold with outline or black box). Font and colours from `brand/brand.md`.
3. Build per `/hyperframes` → `references/captions.md`: one captions host (`data-track-kind="captions"`), groups of the preset's size, one group visible at a time, hard kill at each group's end, fitted with `fitTextFontSize`, inside the safe band, never over the face, never under a graphics card (shift the group or shorten the card).
4. **Old subtitles were covered** (`job.md` → `Burned-in subtitles: yes … mode black`): our captions replace them in the same place, so the black band reads as our caption box.
   - Centre every group vertically on the band's centre (`captions centre y≈…` in `job.md`), full width, one line; size the text to ~55–65 % of the band height (`fitTextFontSize` with that as the max), white, no extra background box or outline needed — the band is the box.
   - Band shown only part of the time (`during <times>`) → in those windows captions sit in the band; outside them use the preset's normal position. If that jumps around visibly, ask whether to extend the black band to the whole clip (`vid.py mask` without `--times`) for one steady position.
   - Mode crop or blur → no band: use the preset's normal caption position.
   - Snapshot at least two moments inside the band to check no old letters peek out above or below; if they do, re-run `vid.py mask` with a larger `--pad`.
5. `npx hyperframes check --json`, snapshot 4–5 moments (including during a card and a B-roll cutaway), preview URL to the person.

Feedback ("bigger", "move up", "yellow highlight", "that word is wrong") → change the style variables or the word, re-check, snapshot what changed. A style the person likes → offer to save it as the preset's caption style in `presets/formats.md`.

Tick step 3 in `job.md`; suggest `/finish`.
