---
name: viral-video-breakdown
description: Download TikTok, Instagram Reels or YouTube Shorts/videos from their links, pull their stats (views, likes, comments, shares, saves, outlier vs the account's usual views, optionally live through Apify), cut them into shots, frames, transcript and on-screen text, and explain the hook and why each video performed. Use when someone pastes one or more TikTok/Instagram/YouTube links and wants them analyzed, broken down or deconstructed, asks "why did this go viral", "what's the hook", "how many views/saves", wants a reference video cut into pieces, or wants viral videos turned into a reusable format template.
---

# Viral video breakdown

Links in → for each video: stats and a verdict, the hook (0–3 s) and why it stops the scroll, a beat map, the craft specs, and the mechanisms that made it work. Optionally a reusable format card. Everything is saved in a library folder so it grows over time.

No questions up front: links in, results out. Keep a task list (download · stats · break down · write up · store).

**Paths.** `<skill>` = this skill's folder (the base directory shown when the skill loads). Run scripts with `python` on Windows, `python3` on Mac/Linux. Quote paths with spaces.

**Library** (`LIB`): `library/` when the current folder is the short-video kit (it has `scripts/vid.py`), otherwise `viral-library/` in the current folder, or the folder the person names.

```
LIB/
  downloads/            <Platform>_<account>_<id>.mp4 + .info.json + .baseline.json (+ .apify.json)
  analyses/<basename>/  analysis.md, facts.json, hook.png, sheet_NN.png, transcript.txt (+ clips/)
  formats/              NN_<slug>.md format cards + README.md (the list of formats)
  index.csv             one row per analysed video
```

## 0. First time on a machine

- FFmpeg must be on PATH (`ffmpeg -version`). Missing → Windows `winget install Gyan.FFmpeg`, Mac `brew install ffmpeg`, then restart the terminal / Claude app.
- Run once, in the background (a few minutes): `python <skill>/scripts/vidkit.py setup`. It makes a private env from an official Python 3.10–3.13 (installs Python 3.12 with winget/Homebrew if the machine only has a newer one, since OCR/Whisper don't support those yet), installs yt-dlp, OCR and Whisper into it, and downloads the Whisper model (~650 MB) into `~/.cache/vidkit`. Tell the person once what it's installing. Re-running it updates yt-dlp.
- Already set up = `~/.cache/vidkit/venv` exists. All scripts switch into that env by themselves.

## 1. Links

- Take every http(s) link from the message (TikTok, Instagram, YouTube). `fetch.py` strips tracking params (`is_from_webapp`, `igsh`, `si`, `utm_*`…).
- If `LIB/index.csv` already lists a link, say so in one line and skip it unless the person asks to redo it.

## 2. Download + stats

```bash
python <skill>/scripts/fetch.py <url> [<url> …] --out LIB/downloads
```

One JSON line per link. Saves the video, yt-dlp's `.info.json` (views, likes, comments, shares, followers, posted date, sound) and `.baseline.json` (median views of the account's latest ~24 posts: TikTok and YouTube only). About 10–30 s per link.

- **Instagram fails** → it retries with Firefox cookies: the person must be logged in to instagram.com in Firefox (Chrome/Edge cookies can't be read on Windows; on Mac `--browser chrome` or `--browser safari` works). Private or deleted posts → report them.
- **Other failures** → re-run setup (updates yt-dlp), retry once, then explain the error plainly and carry on with what did download.
- **No way to download** (e.g. a sandbox that can't reach these sites) → ask the person to download the files and give you the paths; Apify (step 3) can still supply the stats.

## 3. Live stats through Apify (optional)

Use it when the person asks for Apify, for saves, or for fresher numbers, or when Instagram hides views (`view_count` null). Needs a token: env var `APIFY_TOKEN`, or `"apify_token"` in a `config.local.json` in the current folder (in the kit: `python scripts/vid.py config set apify_token <token>`). It's paid per result (fractions of a cent per post): say so the first time. Never print, echo or paste the token anywhere.

```bash
python <skill>/scripts/apify_stats.py <url> [<url> …] --downloads LIB/downloads
```

Writes `<video>.apify.json` next to each downloaded video: views, likes, comments, shares, **saves** (TikTok only), followers, sound. `vidkit.py analyze` merges it, and Apify's numbers win. No token → skip this step and mention once that Apify can add saves and fresher numbers.

## 4. Break each video down

```bash
python <skill>/scripts/vidkit.py analyze LIB/downloads/<file>.mp4 LIB/analyses/<basename> [--lang en] [--clips]
```

About 20 s per 15 s of video; run several in the background for big batches. `--clips` also cuts the video into one MP4 per shot (`clips/shot_NN_<start>-<end>.mp4`). Use it when the person wants the pieces, to study or reuse a shot. `vidkit.py clips <video> <outdir>` does only that.

Then actually look:
- `Read` hook.png and **every** sheet_NN.png. Labels show the time; `CUT` marks a scene change.
- Read facts.json: cuts and pacing, transcript, on-screen text timeline (position, text height %, words per screen), voiceover yes/no + WPM, metrics.
- When on-screen text is the content (list, teleprompter, captions), trust the OCR text over your reading of thumbnails. Music-only audio: say so; `track`/`artist` (or Apify's `sound`) names the sound.
- Whisper auto-detects the language; pass `--lang xx` if it got it wrong. `transcript_status` / `ocr_status` saying "skipped" → run setup.

## 5. Metrics and verdict

From `facts.metrics`: views, likes, comments, shares, saves, followers, posted, engagement %, views/follower, views/day, comments per 1k likes, saves per 1k views, account median, `outlier_x` = views ÷ account median.

- **Outlier**: views ≥ 5× followers or ≥ 5× the account median.
- **Proven format**: the account has ≥ 3 posts over 5× its median in this format, or it's an outlier on 2+ accounts in this batch or the library.
- **Normal for the account**: < 2× median. Still worth studying when the median itself is high (the format works every time).
- Comments per 1k likes above ~20 → comment bait / debate mechanic. Saves per 1k views above ~10 → save-worthy (list, tutorial, reference). Note them.
- Views missing (Instagram, no Apify) → open the post in a browser and read the count if a browser tool is available; otherwise write n/a.

## 6. Write `analysis.md` (one per video)

Follow [references/analysis-guide.md](references/analysis-guide.md): Snapshot · Hook (0–3 s) · Beat map · Craft specs · Why it works (3–5 mechanisms, each tied to a timestamp or a metric, no generic claims) · Template vs variables.

Several links: group the videos that share a format (same visual system + structure) and compare them side by side. Separating what stays fixed (template) from what changes (variables) is the most valuable part.

## 7. Format cards (when asked: "add these to the library", "make a template", "improve <format>")

- **New format** → `LIB/formats/NN_<slug>.md` from [references/format-card.md](references/format-card.md) (next free number), plus a row in `LIB/formats/README.md` (create it with `| # | Format | Card | Proven by | Status |`). A video that matches an existing card updates that card instead of creating a duplicate.
- **Improve an existing format** → append a dated "New reference" section to that card (link, metrics, outlier ×, what this video does better or differently, each with a timestamp), then edit the card's recipe where the evidence is clear, and say what you changed.
- **Adapting to the person's niche**: use what you know (`brand/brand.md` in the kit, the conversation). If you know nothing, keep the recipe generic and offer to adapt it.

## 8. Store

- `LIB/index.csv` (create with this header if missing, UTF-8), one row per video:
  `date_added,url,platform,account,posted,duration_s,views,likes,comments,shares,saves,followers,account_median_views,outlier_x,engagement_pct,verdict,format,analysis_path`
- Videos stay in `downloads/`. They are for study only: don't repost them or reuse their footage, music or a person's likeness in published work.

## 9. Reply

Short. One line per link: account · views · outlier × · the hook in a few words · verdict. Then the 2–3 strongest "why it works" points across the batch, the format card created or updated (if any), and failures with their fix. Offer one next step (for example "make one in this format": in the short-video kit, `/rough-cut` or `/assemble` takes it from there). Don't paste the full analyses; give their paths.
