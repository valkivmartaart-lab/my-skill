# Format card template

File: `LIB/formats/NN_<slug>.md` (NN = next free number). Fill every section from the analyses; leave a section out rather than inventing.

```markdown
# NN · <Format name>

<one-line pitch: what the viewer gets and why they stay>

## Proven by
| Video | Account | Views | Outlier × | Saves / 1k views | Analysis |
|---|---|---|---|---|---|

## Recipe
- **Hook formula** (2–3 fill-in-the-blank variants):
  - "<___> is why your <___> doesn't work"
  - ...
- **Beat structure with timings**: 0–2 s hook · 2–8 s ... · last 2 s ...
- **Text rules**: words per screen, position, case, colours, font style, how long each screen stays.
- **Visual source**: talking head / screen recording / stock / AI images / text on background...
- **Voice**: on-camera, voiceover (AI or human), music only; pace (WPM).
- **Music / sound**: type, level, trending or original.
- **Length** and **ending** (loop, CTA, cliffhanger).
- **Caption + hashtag pattern**.

## Adaptation (only if the niche is known)
- 10 topic ideas for the person's niche.
- A script template with slots.
- 3 ready-to-produce scripts.

## Production
How to make it with the tools at hand (in the short-video kit: `/rough-cut` for talking footage, `/assemble` for generated clips, then `/graphics`, `/captions`, `/finish`), minutes per video, batchable or not, effort 1–5.

## Risks
Anything that relies on a real person's face, voice or personality, a celebrity's likeness, copyrighted footage or music, or a platform trend that may fade. If it only works with a specific person on camera, say so and give the closest variant without them, or mark it "not a fit".

## New references
(dated sections appended when new videos teach something about this format)
```
