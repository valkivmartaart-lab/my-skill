# analysis.md: structure and rules

One file per video, in `LIB/analyses/<basename>/analysis.md`. Write from what you saw in hook.png, the contact sheets and facts.json, not from the caption alone.

## 1. Snapshot

- Link, account, platform, posted date, length.
- Metrics table: views · likes · comments · shares · saves · followers · account median · outlier × · engagement % · comments per 1k likes · saves per 1k views. `n/a` when unknown; note the source (yt-dlp / Apify) and the date.
- Verdict in one line (Outlier / Proven format / Normal for account) and why.

## 2. Hook (0–3 s)

- What's on screen (subject, framing, motion, colour), frame by frame from hook.png.
- On-screen text **verbatim** (OCR `onscreen_text_first_3s`) and where it sits.
- Spoken line **verbatim** (`hook_spoken_first_3_5s`).
- Cuts in the first 3 s (`cuts_in_first_3s`).
- Why it stops the scroll: name the device (curiosity gap, bold claim, identity call-out, pattern interrupt, visual shock, "you're doing X wrong", result first, question...) and what exactly creates it.

## 3. Beat map

| time | visual | on-screen text | voice / audio | job of this beat |
|---|---|---|---|---|

One row per shot or idea change. "Job" = what the beat does for retention: set up, raise the stakes, pay off, reset attention, prove, call to action, loop back.

## 4. Craft specs

- Average shot length, number of shots, cut rhythm (steady, accelerating...).
- Text: words per screen, placement, case, colours, font style, height % of the frame, how long each screen stays.
- Voice: AI or human, WPM, tone; or music only.
- Music / sound: named track if known, trending or original, how it's used (beat-synced cuts, drop at the payoff...).
- Total length; ending (loop back to the start, CTA, cliffhanger, part 2).
- Caption and hashtags.

## 5. Why it works (3–5 mechanisms)

Each mechanism tied to a **timestamp or a metric**. No generic claims ("good editing", "relatable"). Common mechanisms:

- **Curiosity gap / open loop**: a question or promise at 0:01 that is only paid off at 0:2x.
- **Identity call-out**: "if you're a ___" makes the right viewer feel addressed.
- **Pattern interrupt**: a visual or sound that breaks the feed's rhythm in the first second.
- **Payoff density**: a new piece of value every N seconds (count them).
- **Save-worthy format**: list, steps, reference, template (check saves per 1k views).
- **Comment bait / debate**: a polarising claim, a deliberate mistake, "which one are you" (check comments per 1k likes).
- **Rewatch loop**: the end flows into the start, or text too dense to read in one pass.
- **Authority borrowing**: a known person, brand, number or study on screen.
- **Stakes / tension**: a countdown, a challenge, before vs after.
- **Trend riding**: a trending sound or template (check `track`).

## 6. Template vs variables

Two lists: what would stay identical across episodes of this format (structure, timings, visual system, text rules, sound), and what changes per episode (topic, examples, numbers, person). This is what a format card is built from.

## Verdict rules (summary)

- Outlier: views ≥ 5× followers or ≥ 5× account median.
- Proven format: ≥ 3 posts over 5× median on the account in this format, or an outlier on 2+ accounts.
- Normal for account: < 2× median (still study it if the median is high).
