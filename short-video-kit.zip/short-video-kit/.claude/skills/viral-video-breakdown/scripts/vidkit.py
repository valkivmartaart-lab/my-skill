#!/usr/bin/env python3
"""vidkit - break a short-form video into facts Claude can read.

  python vidkit.py setup [--model small|base|tiny]   one-time: private Python env (yt-dlp, OCR,
                                                    Whisper) + speech model, in ~/.cache/vidkit
  python vidkit.py analyze VIDEO.mp4 OUTDIR [--lang en] [--clips]
  python vidkit.py clips   VIDEO.mp4 OUTDIR           cut the video into one MP4 per shot

analyze writes to OUTDIR:
  facts.json      duration, cuts, pacing, transcript, on-screen text timeline, metrics
  hook.png        frames at 0 / 0.5 / 1 / 1.5 / 2 / 3 s
  sheet_NN.png    labelled frames at every cut + at regular steps (12 per sheet)
  transcript.txt  timestamped speech
  clips/          one MP4 per shot (with --clips)
Metrics come from the files fetch.py / apify_stats.py leave next to the video:
VIDEO.info.json (yt-dlp), VIDEO.baseline.json (account median) and VIDEO.apify.json (live stats).
Needs ffmpeg + ffprobe on PATH. Without setup, frames/cuts/metrics still work; speech and OCR are skipped.
"""
import datetime
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _env import HOME, MODELS, VENV, reexec_in_venv, utf8_console, venv_python  # noqa: E402

WHISPER_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-{m}.tar.bz2"
PACKAGES = ["sherpa-onnx", "rapidocr_onnxruntime", "pillow", "numpy", "yt-dlp[default,curl-cffi]"]
TMP = Path(tempfile.mkdtemp(prefix="vidkit_"))


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)


# ---------------------------------------------------------------- setup
def _version(py):
    try:
        r = subprocess.run([*py, "-c", "import sys; print('%d.%d' % sys.version_info[:2])"],
                           capture_output=True, text=True, timeout=30)
        return tuple(int(x) for x in r.stdout.strip().split(".")) if r.returncode == 0 else None
    except Exception:
        return None


def find_python():
    """A Python 3.10-3.13: the OCR/Whisper wheels don't exist for brand-new Python versions yet."""
    cands = []
    if os.environ.get("VIDKIT_PYTHON"):
        cands.append([os.environ["VIDKIT_PYTHON"]])
    cands.append([sys.executable])
    for mi in (12, 13, 11, 10):
        if os.name == "nt":
            if shutil.which("py"):
                cands.append(["py", f"-3.{mi}"])
            local = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Python" / f"Python3{mi}" / "python.exe"
            if local.exists():
                cands.append([str(local)])
        exe = shutil.which(f"python3.{mi}")
        if exe:
            cands.append([exe])
    for c in cands:
        v = _version(c)
        if v and (3, 10) <= v <= (3, 13):
            return c, v
    return None, None


def _get_model(m):
    d = MODELS / f"sherpa-onnx-whisper-{m}"
    keep = {f"{m}-encoder.int8.onnx", f"{m}-decoder.int8.onnx", f"{m}-tokens.txt"}
    if all((d / k).exists() for k in keep):
        print(f"Whisper {m}: present")
        return True
    d.mkdir(parents=True, exist_ok=True)
    print(f"Downloading Whisper {m} (one time, streamed; only the int8 files are kept)...", flush=True)
    try:
        with urllib.request.urlopen(WHISPER_URL.format(m=m), timeout=60) as r, \
                tarfile.open(fileobj=r, mode="r|bz2") as tf:
            for mem in tf:
                name = Path(mem.name).name
                if mem.isfile() and name in keep:
                    with tf.extractfile(mem) as src, open(d / name, "wb") as dst:
                        shutil.copyfileobj(src, dst)
    except Exception as ex:
        print(f"Model download failed: {type(ex).__name__}: {ex}")
        return False
    return all((d / k).exists() for k in keep)


def setup(model="small"):
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        print("ffmpeg/ffprobe not found. Windows: winget install Gyan.FFmpeg  |  Mac: brew install ffmpeg  "
              "-- then restart the terminal / Claude app.")
    HOME.mkdir(parents=True, exist_ok=True)
    vp = venv_python()
    if not vp:
        py, v = find_python()
        if not py and os.name == "nt" and shutil.which("winget"):
            print("No Python 3.10-3.13 found (OCR/Whisper don't support newer versions yet). "
                  "Installing Python 3.12 from python.org with winget...", flush=True)
            subprocess.run(["winget", "install", "-e", "--id", "Python.Python.3.12", "--silent",
                            "--accept-package-agreements", "--accept-source-agreements"])
            py, v = find_python()
        elif not py and sys.platform == "darwin" and shutil.which("brew"):
            print("No Python 3.10-3.13 found. Installing python@3.12 with Homebrew...", flush=True)
            subprocess.run(["brew", "install", "python@3.12"])
            py, v = find_python()
        if not py:
            sys.exit("Need Python 3.10-3.13 for the analysis tools (newer versions lack OCR/Whisper packages). "
                     "Install Python 3.12 from python.org, then re-run setup "
                     "(or set VIDKIT_PYTHON to its python executable).")
        print(f"Creating a private env with Python {v[0]}.{v[1]} in {VENV} ...", flush=True)
        if subprocess.run([*py, "-m", "venv", str(VENV)]).returncode or not venv_python():
            sys.exit("Could not create the env (see above).")
        vp = venv_python()
        subprocess.run([str(vp), "-m", "pip", "install", "-q", "-U", "pip"])
    print("Installing / updating yt-dlp, OCR and Whisper runtime...", flush=True)
    r = subprocess.run([str(vp), "-m", "pip", "install", "-q", "-U", "--disable-pip-version-check", *PACKAGES])
    if r.returncode:
        sys.exit("Package install failed (see above).")
    ok_model = _get_model(model)
    chk = subprocess.run([str(vp), "-c", "import sherpa_onnx, rapidocr_onnxruntime, PIL, numpy, yt_dlp; "
                          "print(yt_dlp.version.__version__)"], capture_output=True, text=True)
    if chk.returncode == 0 and ok_model:
        print(f"ready (yt-dlp {chk.stdout.strip()}, Whisper {model}) - env: {HOME}")
    else:
        print("setup incomplete:", (chk.stderr or "").strip().splitlines()[-1:] or "model missing")


# ---------------------------------------------------------------- media basics
def need_ffmpeg():
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        sys.exit("ffmpeg/ffprobe not found on PATH (Windows: winget install Gyan.FFmpeg | Mac: brew install ffmpeg)")


def probe(v):
    r = json.loads(sh(["ffprobe", "-v", "error", "-print_format", "json", "-show_streams",
                       "-show_format", v]).stdout or "{}")
    if not r.get("streams"):
        sys.exit(f"Not a readable video: {v}")
    vs = next(s for s in r["streams"] if s["codec_type"] == "video")
    num, den = (vs.get("avg_frame_rate") or "30/1").split("/")
    fps = float(num) / float(den) if float(den or 0) else 30.0
    return {"duration_s": round(float(r["format"]["duration"]), 2),
            "width": vs["width"], "height": vs["height"], "fps": round(fps, 1),
            "has_audio": any(s["codec_type"] == "audio" for s in r["streams"])}


def cuts(v, thr=0.3):
    err = sh(["ffmpeg", "-i", v, "-vf", f"select='gt(scene,{thr})',showinfo", "-f", "null", "-"]).stderr
    return [round(float(x), 2) for x in re.findall(r"pts_time:([\d.]+)", err)]


def frame(v, t, out, w=360):
    out = str(out)
    sh(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", v, "-frames:v", "1",
        "-vf", f"scale={w}:-2", out])
    return out if os.path.exists(out) else None


def grid(paths_labels, out, cols=6):
    from PIL import Image, ImageDraw
    ims = [(Image.open(p), lab) for p, lab in paths_labels if p]
    if not ims:
        return
    w, h = ims[0][0].size
    rows = (len(ims) + cols - 1) // cols
    g = Image.new("RGB", (cols * w, rows * (h + 26)), "white")
    d = ImageDraw.Draw(g)
    for i, (im, lab) in enumerate(ims):
        x, y = (i % cols) * w, (i // cols) * (h + 26)
        g.paste(im.resize((w, h)), (x, y + 26))
        d.text((x + 6, y + 6), lab, fill="black")
    g.save(out)


def pcm(v, start=0, dur=None):
    import numpy as np
    cmd = ["ffmpeg", "-v", "error", "-ss", str(start), "-i", v]
    if dur:
        cmd += ["-t", str(dur)]
    raw = subprocess.run(cmd + ["-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                         capture_output=True).stdout
    return np.frombuffer(raw, dtype=np.int16).astype("float32") / 32768.0


# ---------------------------------------------------------------- speech + on-screen text
def whisper_model():
    for m in ("small", "base", "tiny"):
        d = MODELS / f"sherpa-onnx-whisper-{m}"
        if (d / f"{m}-encoder.int8.onnx").exists():
            return d, m
    return None, None


def transcribe(v, lang=""):
    import sherpa_onnx
    d, m = whisper_model()
    if not d:
        raise RuntimeError("no Whisper model (run: vidkit.py setup)")
    rec = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=str(d / f"{m}-encoder.int8.onnx"), decoder=str(d / f"{m}-decoder.int8.onnx"),
        tokens=str(d / f"{m}-tokens.txt"), language=lang, task="transcribe",
        num_threads=os.cpu_count() or 2)

    def run(a):
        s = rec.create_stream()
        s.accept_waveform(16000, a)
        rec.decode_stream(s)
        return s.result.text.strip(), getattr(s.result, "lang", "")

    audio = pcm(v)
    segs, chunk, detected = [], 20 * 16000, ""
    for i in range(0, len(audio), chunk):
        seg = audio[i:i + chunk]
        if len(seg) < 8000 or float(abs(seg).max(initial=0)) < 0.01:
            continue
        txt, lg = run(seg)
        detected = detected or lg
        if txt:
            segs.append({"t": round(i / 16000, 1), "text": txt})
    hook, _ = run(pcm(v, 0, 3.5)) if len(audio) > 8000 else ("", "")
    return segs, hook, detected


def ocr_timeline(v, dur):
    from PIL import Image
    from rapidocr_onnxruntime import RapidOCR
    eng, tl, tmp = RapidOCR(), [], TMP / "ocr.png"
    step = 1.0 if dur <= 90 else dur / 90  # ~90 reads max, long videos sampled more sparsely
    t = 0.2
    while t < dur:
        if frame(v, t, tmp, w=720):
            res, _ = eng(str(tmp))
            boxes = [(b, s) for b, s, c in (res or []) if float(c) > 0.6 and len(s.strip()) > 1]
            if boxes:
                H = Image.open(tmp).size[1]
                text = " ".join(s for _, s in sorted(boxes, key=lambda x: (x[0][0][1], x[0][0][0])))
                ys = [b[0][1] / H for b, _ in boxes]
                hs = [(b[2][1] - b[0][1]) / H for b, _ in boxes]
                pos = ["top", "middle", "bottom"][min(2, int(sum(ys) / len(ys) * 3))]
                entry = {"t": round(t, 1), "text": text, "position": pos,
                         "text_height_pct": round(100 * max(hs), 1), "words": len(text.split())}
                if tl and tl[-1]["text"] == text:
                    tl[-1]["until"] = round(t, 1)
                else:
                    tl.append(entry)
        t += step
    return tl


# ---------------------------------------------------------------- metrics
def sidecar(v, ext):
    p = Path(v).with_suffix(ext)
    if p.exists():
        return p
    cand = glob.glob(glob.escape(str(Path(v).with_suffix(""))) + "*" + ext)
    return Path(cand[0]) if cand else None


def metrics(v):
    m = {}
    p = sidecar(v, ".info.json")
    if p:
        j = json.loads(p.read_text(encoding="utf-8"))
        m = {k: j.get(k) for k in ["webpage_url", "extractor_key", "uploader", "channel", "title",
                                   "description", "upload_date", "duration", "view_count",
                                   "like_count", "comment_count", "repost_count", "save_count",
                                   "channel_follower_count", "track", "artist"]}
        m["sources"] = ["yt-dlp"]
    ap = sidecar(v, ".apify.json")
    if ap:
        a = json.loads(ap.read_text(encoding="utf-8"))
        # Apify is the fresher, explicit lookup: it wins where it has a value.
        for src, dst in [("views", "view_count"), ("likes", "like_count"), ("comments", "comment_count"),
                         ("shares", "repost_count"), ("saves", "save_count"),
                         ("followers", "channel_follower_count"), ("account", "uploader"),
                         ("url", "webpage_url"), ("caption", "description")]:
            if a.get(src) is not None:
                m[dst] = a[src]
        if a.get("posted") and not m.get("upload_date"):
            m["upload_date"] = a["posted"][:10].replace("-", "")
        if a.get("sound") and not m.get("track"):
            m["track"] = a["sound"]
        m["apify_fetched_at"] = a.get("fetched_at")
        m["sources"] = m.get("sources", []) + ["apify"]
    if not m:
        return None
    views = m.get("view_count")
    if views:
        eng = sum(m.get(k) or 0 for k in ["like_count", "comment_count", "repost_count", "save_count"])
        m["engagement_rate_pct"] = round(100 * eng / views, 2)
        if m.get("channel_follower_count"):
            m["views_per_follower"] = round(views / m["channel_follower_count"], 1)
        if m.get("upload_date"):
            age = (datetime.date.today() - datetime.datetime.strptime(m["upload_date"], "%Y%m%d").date()).days
            m["days_live"] = age
            m["views_per_day"] = round(views / max(age, 1))
        if m.get("save_count") is not None:
            m["saves_per_1k_views"] = round(1000 * m["save_count"] / views, 1)
    b = sidecar(v, ".baseline.json")
    if b:
        bl = json.loads(b.read_text(encoding="utf-8-sig"))
        m["account_median_views"] = bl.get("median_views")
        m["account_posts_sampled"] = bl.get("n_posts")
        if views and bl.get("median_views"):
            m["outlier_x"] = round(views / bl["median_views"], 1)
            m["account_posts_over_5x_median"] = sum(1 for x in bl.get("views", []) if x >= 5 * bl["median_views"])
    if m.get("comment_count") and m.get("like_count"):
        m["comments_per_1k_likes"] = round(1000 * m["comment_count"] / m["like_count"], 1)
    return m


# ---------------------------------------------------------------- clips
def split_clips(v, cs, dur, out):
    d = Path(out) / "clips"
    d.mkdir(parents=True, exist_ok=True)
    edges = [0.0] + [c for c in cs if 0 < c < dur] + [dur]
    made = []
    for i, (a, b) in enumerate(zip(edges, edges[1:]), 1):
        if b - a < 0.2:
            continue
        name = d / f"shot_{i:02d}_{a:06.2f}-{b:06.2f}.mp4"
        sh(["ffmpeg", "-v", "error", "-y", "-ss", f"{a:.3f}", "-i", v, "-t", f"{b - a:.3f}",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "160k", str(name)])
        if name.exists():
            made.append({"file": f"clips/{name.name}", "start": a, "end": b})
    return made


# ---------------------------------------------------------------- analyze
def analyze(v, out, lang="", clips=False):
    need_ffmpeg()
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    info = probe(v)
    dur = info["duration_s"]
    cs = cuts(v)
    shots = [b - a for a, b in zip([0] + cs, cs + [dur])]
    facts = {"video": os.path.basename(v), **info,
             "cuts_s": cs, "n_shots": len(shots),
             "avg_shot_s": round(sum(shots) / len(shots), 2),
             "cuts_in_first_3s": sum(1 for c in cs if c < 3)}

    try:
        import PIL  # noqa: F401
        hook = [(frame(v, t, TMP / f"h{t}.png"), f"{t}s") for t in [0, 0.5, 1, 1.5, 2, 3] if t < dur]
        grid(hook, out / "hook.png", cols=6)
        step = 2.0 if dur <= 120 else dur / 60
        times = sorted(set([round(c + 0.15, 2) for c in cs] + [round(x * step, 2) for x in range(int(dur / step) + 1)]))
        times = [t for t in times if t < dur - 0.05]
        pics = [(frame(v, t, TMP / f"f{i}.png", w=240),
                 f"{t:.1f}s" + (" CUT" if any(abs(t - c - 0.15) < 0.01 for c in cs) else ""))
                for i, t in enumerate(times)]
        for n in range(0, len(pics), 12):
            grid(pics[n:n + 12], out / f"sheet_{n // 12 + 1:02d}.png", cols=6)
    except ImportError:
        facts["frames_status"] = "skipped: Pillow missing (run: vidkit.py setup)"

    if info["has_audio"]:
        try:
            segs, hook_line, detected = transcribe(v, lang)
            words = sum(len(s["text"].split()) for s in segs)
            facts.update({"speech_language": detected, "speech_words": words,
                          "speech_wpm": round(words / dur * 60) if dur else None,
                          "voiceover": words >= max(8, dur * 0.8),
                          "hook_spoken_first_3_5s": hook_line, "transcript": segs})
            (out / "transcript.txt").write_text(
                "\n".join(f"[{int(s['t']) // 60:02d}:{int(s['t']) % 60:02d}] {s['text']}" for s in segs),
                encoding="utf-8")
        except Exception as ex:
            facts["transcript_status"] = f"skipped: {type(ex).__name__}: {ex} (run: vidkit.py setup)"
    try:
        tl = ocr_timeline(v, dur)
        facts["onscreen_text"] = tl
        facts["onscreen_text_first_3s"] = " | ".join(e["text"] for e in tl if e["t"] < 3)
    except Exception as ex:
        facts["ocr_status"] = f"skipped: {type(ex).__name__}: {ex} (run: vidkit.py setup)"
    facts["metrics"] = metrics(v)
    if clips:
        facts["clips"] = split_clips(v, cs, dur, out)
    (out / "facts.json").write_text(json.dumps(facts, indent=1, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: facts[k] for k in facts if k not in ("transcript", "onscreen_text", "clips")},
                     indent=1, ensure_ascii=False))


def main():
    try:
        _main()
    finally:
        shutil.rmtree(TMP, ignore_errors=True)


def _main():
    utf8_console()
    a = sys.argv[1:]
    if not a or a[0] in ("-h", "--help"):
        print(__doc__)
        return
    if a[0] == "setup":
        setup(a[a.index("--model") + 1] if "--model" in a else "small")
    elif a[0] in ("analyze", "clips") and len(a) >= 3:
        reexec_in_venv()
        if a[0] == "clips":
            need_ffmpeg()
            info = probe(a[1])
            made = split_clips(a[1], cuts(a[1]), info["duration_s"], a[2])
            print(json.dumps(made, indent=1))
        else:
            analyze(a[1], a[2], a[a.index("--lang") + 1] if "--lang" in a else "", "--clips" in a)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
