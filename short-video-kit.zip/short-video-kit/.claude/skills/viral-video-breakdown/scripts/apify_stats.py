#!/usr/bin/env python3
"""apify_stats - live stats for TikTok / Instagram posts through Apify (optional, paid per result).

  python apify_stats.py URL [URL ...] [--downloads LIB/downloads]

TikTok    -> actor clockworks/tiktok-scraper : views, likes, comments, shares, SAVES, followers, sound
Instagram -> actor apify/instagram-scraper   : views (plays), likes, comments (saves/shares aren't public)
YouTube links are skipped: yt-dlp (fetch.py) already returns views, likes and comments.

Token (never printed): APIFY_TOKEN environment variable, or "apify_token" in a config.local.json
in the current folder or any parent folder. Get one at https://console.apify.com/account/integrations
With --downloads, each result is also saved as <video>.apify.json next to the downloaded video with
the same post id (fetch.py file names end in _<id>.mp4), where `vidkit.py analyze` merges it.
Override actors with --tiktok-actor / --instagram-actor. Standard library only.
"""
import argparse
import datetime
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

API = "https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items?timeout=240"


def token():
    t = os.environ.get("APIFY_TOKEN")
    if t:
        return t.strip()
    d = Path.cwd().resolve()
    for p in [d, *d.parents]:
        f = p / "config.local.json"
        if f.is_file():
            try:
                t = json.loads(f.read_text(encoding="utf-8-sig")).get("apify_token")
            except Exception:
                t = None
            if t:
                return str(t).strip()
    return None


def call(actor, payload, tok):
    req = urllib.request.Request(API.format(actor=actor.replace("/", "~")), method="POST",
                                 data=json.dumps(payload).encode(),
                                 headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return json.load(r)
    except urllib.error.HTTPError as ex:
        body = ex.read().decode("utf-8", "replace")[:300]
        raise RuntimeError(f"Apify HTTP {ex.code}: {body}") from None


def first(*vals):
    for v in vals:
        if v is not None and v != -1:
            return v
    return None


def post_id(url):
    m = re.search(r"/video/(\d+)", url) or re.search(r"/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url)
    return m.group(1) if m else None


def norm_tiktok(it):
    a, mm, vm = it.get("authorMeta") or {}, it.get("musicMeta") or {}, it.get("videoMeta") or {}
    sound = " - ".join(x for x in [mm.get("musicName"), mm.get("musicAuthor")] if x) or None
    return {"platform": "TikTok", "id": str(it.get("id") or ""),
            "url": first(it.get("webVideoUrl"), it.get("submittedVideoUrl")),
            "account": first(a.get("name"), a.get("uniqueId")), "followers": a.get("fans"),
            "posted": it.get("createTimeISO"), "duration_s": vm.get("duration"),
            "views": it.get("playCount"), "likes": it.get("diggCount"), "comments": it.get("commentCount"),
            "shares": it.get("shareCount"), "saves": it.get("collectCount"),
            "caption": it.get("text"), "sound": sound, "original_sound": mm.get("musicOriginal")}


def norm_instagram(it):
    mi = it.get("musicInfo") or {}
    sound = " - ".join(x for x in [mi.get("song_name"), mi.get("artist_name")] if x) or None
    return {"platform": "Instagram", "id": it.get("shortCode"), "url": first(it.get("url"), it.get("inputUrl")),
            "account": it.get("ownerUsername"), "followers": None, "posted": it.get("timestamp"),
            "duration_s": it.get("videoDuration"),
            "views": first(it.get("videoPlayCount"), it.get("igPlayCount"), it.get("videoViewCount")),
            "likes": first(it.get("likesCount")), "comments": first(it.get("commentsCount")),
            "shares": None, "saves": None, "caption": it.get("caption"), "sound": sound}


def save_next_to_video(rec, downloads):
    if not downloads or not rec.get("id"):
        return None
    hits = [p for p in Path(downloads).glob(f"*_{rec['id']}.mp4")]
    if not hits:
        return None
    dest = hits[0].with_suffix(".apify.json")
    dest.write_text(json.dumps(rec, indent=1, ensure_ascii=False), encoding="utf-8")
    return str(dest)


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("urls", nargs="+")
    ap.add_argument("--downloads", help="folder with fetch.py downloads; writes <video>.apify.json there")
    ap.add_argument("--tiktok-actor", default="clockworks/tiktok-scraper")
    ap.add_argument("--instagram-actor", default="apify/instagram-scraper")
    a = ap.parse_args()
    tok = token()
    if not tok:
        sys.exit("No Apify token. Set the APIFY_TOKEN environment variable, or put "
                 '{"apify_token": "..."} in config.local.json (kept private). '
                 "Token: https://console.apify.com/account/integrations")
    urls = list(dict.fromkeys(u.strip() for u in a.urls if u.lower().startswith("http")))
    tt = [u for u in urls if "tiktok.com" in u]
    ig = [u for u in urls if "instagram.com" in u]
    for u in urls:
        if u not in tt and u not in ig:
            print(json.dumps({"url": u, "ok": False, "note": "skipped: only TikTok and Instagram go through Apify"}))
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    jobs = []
    if tt:
        jobs.append((a.tiktok_actor, {"postURLs": tt, "resultsPerPage": 1, "shouldDownloadVideos": False,
                                      "shouldDownloadCovers": False, "shouldDownloadSubtitles": False},
                     tt, norm_tiktok))
    if ig:
        jobs.append((a.instagram_actor, {"directUrls": ig, "resultsType": "posts", "resultsLimit": 1,
                                         "addParentData": False}, ig, norm_instagram))
    for actor, payload, asked, norm in jobs:
        try:
            items = call(actor, payload, tok)
        except Exception as ex:
            for u in asked:
                print(json.dumps({"url": u, "ok": False, "note": str(ex)[:300]}))
            continue
        recs = [dict(norm(it), actor=actor, fetched_at=now) for it in items if isinstance(it, dict) and not it.get("error")]
        errors = [it for it in items if isinstance(it, dict) and it.get("error")]
        by_id = {r["id"]: r for r in recs if r.get("id")}
        for i, u in enumerate(asked):
            r = by_id.get(post_id(u)) or (recs[i] if len(recs) == len(asked) else None)
            if not r:
                err = next((e.get("error") for e in errors if u.rstrip("/") in str(e.get("url") or e.get("inputUrl") or "")), None)
                print(json.dumps({"url": u, "ok": False, "note": err or "no result (private, deleted or short link)"}))
                continue
            r = dict(r, requested_url=u)
            saved = save_next_to_video(r, a.downloads)
            print(json.dumps({"url": u, "ok": True, "saved": saved,
                              **{k: r.get(k) for k in ("account", "views", "likes", "comments", "shares", "saves", "followers", "posted")}},
                             ensure_ascii=False))


if __name__ == "__main__":
    main()
