"""Shared helpers: the private Python env that `vidkit.py setup` creates (yt-dlp, OCR, Whisper).

Location: $VIDKIT_HOME, default ~/.cache/vidkit  (venv/ + models/).
"""
import os
import subprocess
import sys
from pathlib import Path

HOME = Path(os.environ.get("VIDKIT_HOME") or Path.home() / ".cache" / "vidkit")
VENV = HOME / "venv"
MODELS = HOME / "models"


def utf8_console():
    # Windows consoles default to cp1252 when piped; force UTF-8 so accents and emoji print.
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass


def venv_python():
    p = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    return p if p.exists() else None


def reexec_in_venv():
    """Re-run the current script with the vidkit env's Python when it exists and we're not in it."""
    vp = venv_python()
    if not vp or os.environ.get("VIDKIT_IN_VENV"):
        return
    try:
        same = Path(sys.prefix).resolve() == VENV.resolve()
    except OSError:
        same = False
    if same:
        return
    env = dict(os.environ, VIDKIT_IN_VENV="1", PYTHONIOENCODING="utf-8")
    sys.exit(subprocess.call([str(vp), *sys.argv], env=env))
