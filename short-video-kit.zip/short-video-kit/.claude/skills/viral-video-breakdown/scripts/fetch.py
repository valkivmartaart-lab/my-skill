#!/usr/bin/env python3
"""fetch - download TikTok / Instagram / YouTube videos with their stats (yt-dlp).

  python fetch.py URL [URL ...] --out LIB/downloads [--browser firefox] [--no-baseline]

Per link, in --out:
  <Platform>_<account>_<id>.mp4         the video
  <same>.info.json                      views, likes, comments, shares, followers, posted date, sound...
  <same>.baseline.json                  median views of the account's latest ~24 posts (TikTok, YouTube)
Prints one JSON line per link: {"url", "ok", "file", "note"}.

Instagram often needs a logged-in browser: on failure it retries with cookies from --browser
(default firefox; Chrome/Edge cookies can't be read on Windows - on Mac, chrome or safari work).
Runs inside the vidkit env when `vidkit.py setup` has been run; otherwise needs `pip install yt-dlp`.
"""
import argparse
import json
import re
import sys
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _env import reexec_in_venv, utf8_console  # noqa: E402

TRACKING = re.compile(r"^(utm_.*|is_from_webapp|sender_device|sender_web_id|igsh|igshid|si|_r|_t|"
                      r"share_.*|feature|t|lang|q|refer|referer)$", re.I)


def clean(u):
    p = urllib.parse.urlsplit(u.strip())
    q = [(k, v) for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True) if not TRACKING.match(k)]
    return urllib.parse.urlunsplit((p.scheme, p.netloc, p.path, urllib.parse.urlencode(q), ""))


def opts(out, browser=None):
    o = {"outtmpl": str(out / "%(extractor_key)s_%(uploader,channel|unknown)s_%(id)s.%(ext)s"),
         "restrictfilenames": True, "noplaylist": True, "writeinfojson": True,
         "format": "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b", "merge_output_format": "mp4",
         "quiet": True, "no_warnings": True, "noprogress": True, "retries": 3}
    if browser:
        o["cookiesfrombrowser"] = (browser,)
    return o


def download(url, out, browser):
    from yt_dlp import YoutubeDL
    with YoutubeDL(opts(out, browser)) as y:
        info = y.extract_info(url, download=True)
        reqs = info.get("requested_downloads") or [{}]
        path = reqs[0].get("filepath") or y.prepare_filename(info)
    path = Path(path)
    if path.suffix != ".mp4" and path.with_suffix(".mp4").exists():
        path = path.with_suffix(".mp4")
    return info, path


def baseline(info, video):
    """Median views of the account's latest ~24 posts, to tell a real outlier from a big account."""
    from yt_dlp import YoutubeDL
    key = (info.get("extractor_key") or "").lower()
    if "instagram" in key:
        return None  # yt-dlp can't list Instagram profiles
    acct = info.get("uploader_url") or info.get("channel_url")
    if not acct:
        return None
    if key.startswith("youtube") and "/shorts/" in (info.get("webpage_url") or ""):
        acct = acct.rstrip("/") + "/shorts"
    with YoutubeDL({"extract_flat": "in_playlist", "playlist_items": "1:24", "quiet": True,
                    "no_warnings": True, "skip_download": True}) as y:
        pl = y.extract_info(acct, download=False) or {}
    views = sorted(int(e["view_count"]) for e in (pl.get("entries") or [])
                   if e and isinstance(e.get("view_count"), (int, float)))
    if len(views) < 3:
        return None
    bl = {"profile": acct, "n_posts": len(views), "median_views": views[len(views) // 2], "views": views}
    video.with_suffix(".baseline.json").write_text(json.dumps(bl), encoding="utf-8")
    return bl


def main():
    utf8_console()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("urls", nargs="+")
    ap.add_argument("--out", required=True, help="folder for videos + .info.json (e.g. LIB/downloads)")
    ap.add_argument("--browser", default=None, help="browser to read cookies from for Instagram (default: firefox on retry)")
    ap.add_argument("--no-baseline", action="store_true", help="skip the account median lookup")
    a = ap.parse_args()
    reexec_in_venv()
    try:
        import yt_dlp  # noqa: F401
    except ImportError:
        sys.exit("yt-dlp missing: run  python vidkit.py setup  (or: python -m pip install -U yt-dlp)")
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    any_ok = False
    for raw in dict.fromkeys(u for u in a.urls if u.lower().startswith("http")):
        url = clean(raw)
        res = {"url": url, "ok": False, "file": None, "note": ""}
        try:
            try:
                info, path = download(url, out, a.browser)
            except Exception:
                if "instagram.com" not in url or a.browser:
                    raise
                info, path = download(url, out, "firefox")
                res["note"] = "used Firefox cookies; "
            res.update(ok=path.exists(), file=str(path))
            any_ok |= res["ok"]
            if res["ok"] and not a.no_baseline:
                try:
                    bl = baseline(info, path)
                    res["note"] += f"account median {bl['median_views']} views over {bl['n_posts']} posts" if bl \
                        else "no baseline (Instagram or account listing unavailable)"
                except Exception as ex:
                    res["note"] += f"baseline failed: {type(ex).__name__}"
        except Exception as ex:
            msg = str(ex).replace("\n", " ")
            res["note"] = re.sub(r"\x1b\[[0-9;]*m", "", msg)[-300:]
            if "instagram.com" in url:
                res["note"] += " | Instagram: log in to instagram.com in Firefox (or pass --browser) and retry"
            elif "tiktok.com" in url and "403" in msg:
                res["note"] += (" | TikTok blocked the request: run `vidkit.py setup` (adds curl-cffi browser "
                                "impersonation and updates yt-dlp), then retry")
        print(json.dumps(res, ensure_ascii=False), flush=True)
    sys.exit(0 if any_ok else 1)


if __name__ == "__main__":
    main()
