---
name: assemble
description: Step 1 for generated footage — build a video from AI avatar clips (HeyGen, Seedance, Kling, Veo, Google Flow…), B-roll, product shots and screen captures, following a script or shot list. Use for UGC/avatar ads, course promos, faceless videos, or when the person says "assemble", "stitch these clips", "make an ad from these", "make a promo with an avatar".
---

# Assemble

Generated clips usually play clean, so instead of cutting a long take we **sequence shots**. Output: a HyperFrames composition in `comp/` with every shot on the timeline, and `work/cut.words.json` (the voice track's words) for graphics and captions.

## 1. Script and shot list
If the person gives only an idea, write the script first (see `presets/formats.md` → structure for the preset; for `ugc-ad`: hook → problem → solution/demo → proof → CTA). Keep spoken lines short and natural — contractions, a small hesitation, no corporate tone. No invented testimonials, results or income claims.

Then write `work/shots.md` — one row per shot:

| # | File (in raw/) | In–out (s) | Role | Voice | On-screen text |
|---|---|---|---|---|---|
| 1 | avatar_hook.mp4 | 0.0–2.4 | hook | clip audio | "I made this ad in 10 min" |
| 2 | broll_phone.mp4 | 1.0–3.0 | B-roll | VO line 2 | — |

Show the shot list (it's quick to approve) before building, unless the person asked for no stops.

## 2. Get the media
- **Clips the person made elsewhere** (Seedance, Kling, Veo, Flow, Higgsfield…): they go in `raw/`. If a shot is missing, list exactly what to generate: the start frame to make in Nano Banana / the image tool, and a motion prompt in this order: look and place · what must stay the same · the one action · sound ("no slow motion, sound effects only, no music").
- **Avatar talking shots via HeyGen:** the `/media-use` skill drives the `heygen` CLI (`references/operations.md`: `heygen video create` with a script or a recorded track). It costs credits — confirm first. Save outputs in `raw/`.
- **Voiceover instead of on-camera speech:** an ElevenLabs/MiniMax file the person provides, or `npx hyperframes tts` (free, local Kokoro) via `/media-use`. Put it in `raw/`.
- **YouTube clips:** `python scripts/yt_download.py "<url>" --start <t> --end <t>` saves only that section as MP4 in `inbox/`; copy it into `raw/`.
- **Recreating a format studied with `/viral-video-breakdown`:** read its format card in `library/formats/` and follow its recipe (hook formula, beat timings, text rules) for the script and shot list. Never reuse the studied video's own footage or music.
- **Music:** see `/finish`.

## 3. Prepare the footage
- Check each file: `python scripts/vid.py info <clip>` (duration, size, fps, audio). Clips with a different aspect from the preset are recomposed in the composition (crop with `object-fit`/`clip-path`), never stretched.
- **Old subtitles:** AI generators and downloaded clips often carry burned-in captions. Run `python scripts/vid.py subs <clip>` on every clip, look at its contact sheet, and mask confirmed ones before grading (`python scripts/vid.py mask <clip> --scan <…subs.json>`, default black band; `--mode crop` when the band is at the edge). Same rules and `job.md` note as `/rough-cut` step 2. Use the `-nosubs` file from then on.
- For B-roll clips with several shots, `python scripts/vid.py scenes <clip>` gives the shot list and a contact sheet — pick in–out points from it rather than guessing.
- `ugc-ad` preset: grade every AI clip with `python scripts/vid.py grade <clip> --out projects/<job>/work/<name>-graded.mp4` (not the HeyGen avatar shot if it already looks like phone footage — compare one frame of each). Add `--grain 4` if a clip looks plastic.
- If a clip's sound has music in it and the person adds their own music, regenerate the clip asking for "no music" rather than muting it (muting kills the sound effects).

## 4. Build the timeline in HyperFrames
```bash
cd projects/<job>/comp && npx hyperframes init . --resolution portrait --non-interactive --skip-transcribe
```
(`--resolution landscape` for 16:9 presets; check `init --help` if it refuses a non-empty folder.) Copy the footage into `comp/assets/`, then write `index.html` per `/hyperframes` (`references/format.md`): one `<video class="clip">` per shot, trimmed with `data-media-start` + `data-duration` — no re-encoding — placed back to back. Clip audio stays on with `data-has-audio="true"`; a separate VO is its own `<audio id="vo">`. Cuts land on the sentence; shots of 1–3 s for 9:16.

## 5. Voice transcript
Render the audio of the assembled timeline once (`npx hyperframes render --quality draft --output ../work/assembly.draft.mp4`), then:
```bash
node .claude/skills/media-use/scripts/transcribe.mjs --input projects/<job>/work/assembly.draft.mp4 --out projects/<job>/work/cut.words.json
python scripts/words.py fix projects/<job>/work/cut.words.json brand/caption-corrections.json
```
(If the voice came from `npx hyperframes tts` or HeyGen, its `audio_meta.json` already has word timings — use those and skip this.)

## 6. Show and lock
Start the preview (`npx hyperframes preview --background`), check the URL answers 200, give it to the person. Fix shot order/trims from their notes with `npx hyperframes timeline` edits (`/hyperframes-cli`). When they approve: tick step 1 in `job.md`, log the shot list as final, suggest `/graphics`.
