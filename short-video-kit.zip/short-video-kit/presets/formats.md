# Format presets

Only graphics, captions and finish change by preset; the cut works the same everywhere. Pick the preset when creating the job (`python scripts/vid.py new <preset> …`). If the person doesn't say, infer it: a course module → `lesson`; a TikTok/Reel with graphics → `short-explainer`; a quick talking clip → `short-raw`; anything promoting a product or offer with an avatar → `ugc-ad`.

Every preset scans camera and AI footage for old burned-in subtitles at intake and replaces them (black band under our own captions by default — see `/rough-cut` step 2). Music: a file you give, a Jamendo search (`vid.py music search`), or generated.

All 9:16 presets respect the platform safe band (HyperFrames `/hyperframes` → `references/types/vertical.md`): no text above 168 px or below 1330 px, nothing under the right-hand action rail.

---

## `lesson` — course lesson / YouTube (16:9)

| | |
|---|---|
| Canvas | 1920×1080, 30 fps |
| Typical length | 2–3 min (course), any length for YouTube |
| Footage | Talking head, screen recording, or both (screen full frame + face picture-in-picture bottom-right, 460×258 at 28 px from the edges) |
| Graphics | Title card (≤ 3 s) · lower third with speaker name on first appearance · key-point cards in the right 42 % side panel (glass, dark scrim) · numbered list cards for steps · callout arrows/zoom punch-ins on screen recordings · chapter cards between sections · end card with the next lesson. Density: one card per 8–12 s up to 3 min. |
| Captions | Not burned in. Export an `.srt` next to the MP4 (YouTube and most course platforms take it). |
| Music | Optional, very low (−28 to −30 dB under voice), off by default for lessons |
| Finish | `--quality delivery`, 30 fps. No realism grade. |
| Hook (cold open) | Off by default; offer once for YouTube videos |
| Cuts & transitions | No punch-ins by default; one subtle transition style at chapter breaks only |
| B-roll | Full frame or picture-in-picture over the talking head, 3–6 s, where the words describe it |

## `short-explainer` — TikTok / Reels / Shorts with graphics (9:16)

| | |
|---|---|
| Canvas | 1080×1920, 30 fps |
| Typical length | 20–60 s |
| Footage | Talking head, reframed to the bottom half (0, 960, 1080×960) when a card is up, full frame otherwise |
| Graphics | Cards in the top half (0, 0, 1080×844): key word, number, list, before/after, tool logo. A new beat every 2–4 s. Hook line on screen from frame 0. Punch-ins on emphasis. |
| Captions | Centred between cards and face, locked position, 3–5 words per group, active word highlighted in the brand accent |
| Music | Yes, −20 to −23 dB under voice, ducked |
| Finish | `--quality delivery`, 30 fps |
| Hook (cold open) | On — best line copied to the front, white flash at the seam |
| Cuts & transitions | Punch-in alternation (1.00 ↔ 1.12) on jump cuts; transitions at the hook seam and section breaks only |
| B-roll | Top half while the face stays in the bottom half, or full frame 1.5–3 s |

## `short-raw` — raw talking clip (9:16)

| | |
|---|---|
| Canvas | 1080×1920, 30 fps |
| Typical length | 15–45 s |
| Footage | Talking head full frame, tight cut, punch-in every 4–6 s to keep motion |
| Graphics | One hook card for the first 1.5–2.5 s (one bold line, max ~8 words), then nothing but captions. Optional CTA line in the last 2 s. |
| Captions | Low, under the face (inside the safe band, ending above 1330 px), 2–3 words per group, high energy |
| Music | Optional, −23 dB |
| Finish | `--quality delivery`, 30 fps |
| Hook (cold open) | On — best line copied to the front, white flash at the seam |
| Cuts & transitions | Punch-in alternation on jump cuts; no transitions besides the hook seam |
| B-roll | Sparing: full frame 1.5–2.5 s, only where it clearly illustrates the words |

## `ugc-ad` — AI avatar / UGC ad (9:16)

| | |
|---|---|
| Canvas | 1080×1920, 30 fps (render 60 fps for Facebook/Meta) |
| Typical length | 15–30 s |
| Footage | Assembled with `/assemble`: avatar talking shots (HeyGen or other) + B-roll (product, app screen, lifestyle). Cut on the sentence; shots of 1–3 s. |
| Structure | Hook (0–2 s) → problem → solution/demo → proof (real, never invented) → CTA (last 3 s) |
| Graphics | Hook text from frame 0 · product/app name card · price or offer card if given · CTA end card ("Link in bio", "Try it free"… — from `brand/brand.md`). Keep it native-looking: few cards, no glossy motion design. |
| Captions | TikTok style, centred-low, 2–4 words, bold with outline or black box |
| Music | Light, −24 dB, or none if the avatar clip has ambience |
| Finish | **Phone-realism grade on the footage** (`python scripts/vid.py grade` before compositing), `--quality delivery`. Ask whether to render at 60 fps for Meta ads. |
| Hook (cold open) | Comes from the script: the first shot is the hook (no copy needed) |
| Cuts & transitions | Shot changes are the cuts; no transitions, or one before the CTA |
| B-roll | Part of the shot list in `/assemble` |
