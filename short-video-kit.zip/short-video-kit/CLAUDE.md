# Video Editor — instructions for Claude

This folder is an automated video editor. The person drops in footage (a raw talking-head take, a screen recording, AI avatar clips, B-roll) and you take it to a finished MP4 in a few steps, using **HyperFrames** (HTML → video, by HeyGen) as the engine and **FFmpeg** for file work.

It produces four formats (see `presets/formats.md`): course **lessons** (16:9), **short explainers** (9:16), **short raw** talking clips (9:16), and **UGC / avatar ads** (9:16).

It also studies other people's videos: paste TikTok / Instagram / YouTube links and `/viral-video-breakdown` downloads them, pulls their stats, cuts them into shots, frames, transcript and on-screen text, and explains the hook and why they performed. Results go to `library/`.

## First run

If `.claude/skills/hyperframes/` is missing, or `npx hyperframes doctor --json` does not report `.ok: true`, run the setup (`setup.cmd` on Windows, `./setup.sh` on Mac) and fix whatever it reports before anything else. Ask before installing the Parakeet model (~640 MB).

## The pipeline

Same steps for every job. Each step has a skill; run the step the person asks for, then stop and show the result.

| # | Step | Skill | Output |
|---|------|-------|--------|
| 0 | Research (optional): break down viral videos from their links — stats, hook, beat map, why it works, format card | `/viral-video-breakdown` | `library/analyses/<video>/analysis.md`, `library/formats/`, `library/index.csv` |
| 1 | Intake (old-subtitle scan) + rough cut + hook first (talking footage) | `/rough-cut` | `work/cut.mp4`, `work/cut.words.json`, `work/cut-segments.json`, `work/script.md` |
| 1b | Assemble (AI avatar clips + B-roll, from a shot list; old-subtitle scan per clip) | `/assemble` | `comp/` with the clips on a timeline, `work/cut.words.json` |
| 2 | Graphics: plan → approve → build → second pass — incl. B-roll cutaways, punch-ins on jump cuts, transitions at the hook seam and section breaks | `/graphics` | `comp/` composition, live preview URL |
| 3 | Captions (9:16 formats by default; over the black band where old subtitles were covered) | `/captions` | captions track in `comp/` |
| 4 | Finish: music (file, Jamendo search or generated), loudness, render, export | `/finish` | `outputs/<job>.final.mp4` + `<job>.final.md` post copy (IG/TikTok caption, YouTube title + description) next to every copy (+ Downloads, + music credit) |

Use `/rough-cut` when the footage is one person talking with mistakes and silences to remove. Use `/assemble` when the footage is several generated clips that already play clean (HeyGen avatar, Seedance, Kling, Veo, Flow…).

**Autopilot.** If the person says "do it all", "full auto" or "no stops", run every step with preset defaults, stop only once at the end on the live preview, and render when they approve. Still stop before anything that costs money (a HeyGen avatar generation).

## Jobs and folders

```
projects/<job>/
  raw/        originals, copied in, never modified
  work/       transcripts, cut plan, cut.mp4, graded or polished intermediates
  comp/       the HyperFrames project (index.html, compositions/, assets/)
  job.md      the job card: preset, status of each step, decisions taken
outputs/      finished videos only: <job>.final.mp4 + <job>.final.md (post copy, same name)
brand/        brand.md (colours, fonts, logo, tone), caption-corrections.json, assets/
music/        the person's music library + CREDITS.txt for downloaded tracks
inbox/        videos downloaded with yt_download.py, waiting for `vid.py new`
library/      viral video breakdowns: downloads/, analyses/, formats/, index.csv
config.local.json   local keys (Jamendo client ID, Pixabay key, Apify token) — private, never shared, git-ignored
presets/      formats.md
scripts/      helper scripts (below)
```

- Start every job with `python scripts/vid.py new` — it creates the folders, copies the raw files and writes `job.md`.
- **Read `job.md` first** whenever the person resumes a job in a new chat, and update it at the end of every step (status, what was decided, anything the person asked to keep). A new chat must be able to pick up from `job.md` alone.
- `<job>` is `YYYY-MM-DD-short-slug`, e.g. `2026-10-27-day3-avatars`.

## Scripts

| Script | What it does |
|---|---|
| `python scripts/vid.py new <preset> <slug> <file>…` | Create a job, copy raw files, write `job.md` |
| `python scripts/yt_download.py "<url>" [-q 1080] [-a] [--start t --end t]` | Download a YouTube video (or audio, or one section) as MP4 into `inbox/`, ready for `vid.py new` (needs `pip install -U yt-dlp`) |
| `python scripts/words.py show <words.json>` | Print a transcript as numbered words with timings and pauses — read this, never the raw JSON |
| `python scripts/words.py ranges <words.json> "12-18,40-41"` | Turn word-index ranges into padded time ranges for `--remove` |
| `python scripts/words.py fix <words.json> brand/caption-corrections.json` | Fix brand names and spellings in a transcript (in place) |
| `python scripts/words.py srt <words.json> <out.srt>` | Write an SRT subtitle file from a transcript |
| `python scripts/vid.py polish <in> <out>` | High-pass, light denoise, loudness to −16 LUFS (video stream copied) |
| `python scripts/vid.py grade <in> [opts]` | "Shot on a phone" colour grade for AI footage (ugc-ad preset) |
| `python scripts/vid.py finalize <job> <rendered.mp4>` | Verify the render, copy video + `work/post.md` (as `<job>.final.md`) to `outputs/`, Downloads and each `--to <folder>`, mark the job exported |
| `python scripts/vid.py prune <job>` | Delete heavy intermediates of an exported job (keeps raw, comp, transcripts) |
| `python scripts/vid.py info <file>` | Duration, size, fps, audio of a media file |
| `python scripts/vid.py open <file\|url>` | Open a file in the default player/app (or a page in the browser) so the person can review it |
| `python scripts/vid.py subs <file>` | Detect soft subtitle tracks and burned-in text bands; contact sheet with a pixel ruler + `<stem>.subs.json` |
| `python scripts/vid.py mask <file> --scan <subs.json> [--mode black\|blur\|crop]` | Cover, blur or crop out old subtitles (no band: strip soft tracks only) |
| `python scripts/vid.py coldopen <cut> --start A --end B --words … --flash` | Copy the hook to the front, shift the transcript, optional white flash at the seam |
| `python scripts/vid.py cutpoints <cut-segments.json> --video <cut> [--offset H]` | Exact join times in the cut, snapped to real frames (punch-ins, transitions) |
| `python scripts/vid.py scenes <broll>` | Shot list + contact sheet of a B-roll clip |
| `python scripts/vid.py music search … / open <n> / get <n> --job <job>` | Search Jamendo, listen, download with license check and credit line |
| `python scripts/vid.py stock search <words> --job <job> [--photo] / open <n> --job <job> / get <n> --job <job>` | Search Pixabay stock videos or photos (numbered preview sheet), download one into `raw/stock/` with its source logged — **only when the person asks** |
| `python scripts/vid.py config set jamendo_client_id <ID>` / `pixabay_key <KEY>` / `apify_token <TOKEN>` | Save a local key in `config.local.json` (never echo a key back) |

The breakdown skill has its own scripts in `.claude/skills/viral-video-breakdown/scripts/` (`fetch.py`, `vidkit.py`, `apify_stats.py`); its SKILL.md explains them.

## Platform: Windows first (also works on Mac)

Assume **Windows** unless the person is on a Mac. On Windows, commands run in Git Bash, so:
- Use `python` (or `py` if `python` isn't found), never `python3`. Never Mac-only commands (`open`, `say`, `brew`). On a Mac, use `python3`.
- Paths the person pastes look like `"C:\Users\<name>\Videos\take 1.mp4"`. Keep the quotes; convert backslashes to forward slashes (`"C:/Users/<name>/Videos/take 1.mp4"`) — Python, Node and FFmpeg all accept that. Quote every path that may contain spaces.
- File work goes through `scripts/vid.py` and `scripts/words.py` (pure Python, same behaviour on every OS) rather than ad-hoc shell pipelines.
- If `ffmpeg`, `node` or `python` is "not found" right after setup, the Claude app needs a restart to pick up the new PATH — say so.
- A render that is very slow usually means Chrome has no GPU; `npx hyperframes doctor --json` shows it. Draft renders (`--quality draft`) are fine for checks.

HyperFrames' own skills (`/hyperframes`, `/hyperframes-cli`, `/media-use`, `/hyperframes-registry`) are installed in `.claude/skills/`. They are the reference for **how** to build compositions, captions, transcription, cuts, ducking and grades; the skills in this folder say **what** to build and in what order. When they conflict on a style or layout choice, `presets/formats.md` and `brand/brand.md` win; on technical rules (the HyperFrames contract), HyperFrames wins.

## Rules

1. **Never touch `raw/`.** Work on copies.
2. **Lock the cut before graphics.** Graphics are timed to the cut; changing the cut afterwards means redoing them. If the person changes the cut after graphics exist, say so and re-time the affected beats.
3. **Transcribe once per file.** Transcribe the raw take for the rough cut, then the cut file once for graphics and captions. Never re-transcribe a file you already have a `*.words.json` for.
4. **Language.** Default English. For French or another language, say so to the transcriber (Parakeet detects it; with whisper use `--model small --language fr`). Never use an `.en` model on non-English speech: it translates.
5. **Run `words.py fix` on every transcript** before using it for captions or on-screen text.
6. **Review in the live preview, render once.** Iterate in `npx hyperframes preview` (the person can also click an element there and say "move this"). Render with `--quality draft` only to check something specific; the delivery render happens in `/finish`.
7. **Show, don't describe.** After each step, give the person what to look at (open the file with `python scripts/vid.py open <path>`, or the preview URL) and one line on what changed. No step-by-step recaps.
8. **AI content.** Never fabricate testimonials or results in ad scripts and on-screen text; avatar ads are clearly a presenter, not a customer review. Remind the person once per ad job to tick the platform's AI-generated content label when posting.
9. **Cost.** Confirm before any paid generation you chose to run (HeyGen avatar video, paid TTS). What the person explicitly asked for just runs.
10. **Brand.** Colours, fonts and logo come from `brand/brand.md`. If a value there is still a placeholder, use the default listed next to it and mention once that it can be filled in.
11. **Music rights.** Only tracks the person owns, royalty-free libraries, or Jamendo tracks whose license allows the use: no non-commercial track in an ad or anything promoting a paid product. Always pass the credit line on at export.
12. **Look before acting on detection.** `subs` and `scenes` give numbers and a contact sheet; read the sheet image before masking or placing B-roll — the detector can flag a sign or a T-shirt print as text.
13. **Stock footage on request only.** Use Pixabay stock videos or photos (`vid.py stock`) only when the person asks for them in that job — never automatically, not even in autopilot. See `/graphics` → Stock footage.
14. **Studied videos stay references.** Videos downloaded into `library/` are for analysis only: never put their footage, music or the people in them into a job's `raw/` unless the person says they have the rights. Recreate the format, not the video.
