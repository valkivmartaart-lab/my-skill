# Brand

Fill in the values marked `TODO`. Until then Claude uses the default in brackets.

## Identity
- Brand / product name: TODO  [default: none — no brand name on screen]
- Tagline: TODO  [default: none]
- CTA text: TODO  [default: "Link in bio"]
- Niche and audience (used to adapt viral formats): TODO  [default: ask once when it matters]

## Colours (hex)
- Accent: TODO  [default: #FF5A1F — orange, used for highlights, active caption word, CTA]
- Dark: TODO  [default: #0F1016 — card backgrounds, caption boxes]
- Light: TODO  [default: #F7F5F0 — text on dark]
- Secondary: TODO  [default: #7C5CFF — sparingly, for charts and second-level emphasis]

## Type (HyperFrames bundled fonts resolve by name: Inter, Montserrat, Outfit, Poppins, Archivo Black, League Gothic, Oswald…)
- Headlines and hooks: TODO  [default: Archivo Black]
- Body, cards, lower thirds: TODO  [default: Inter 700]
- Captions: TODO  [default: Montserrat 900, uppercase off]
- A custom font goes in `brand/assets/fonts/` as .woff2 and is copied into each job's `comp/assets/fonts/` with an `@font-face`.

## Logo and assets
- Logo (transparent PNG or SVG): `brand/assets/logo.png`  TODO — add the file
- Presenter photo for lower thirds (optional): `brand/assets/`
- Recurring AI avatar reference images (optional): `brand/assets/avatars/`

## Tone on screen
- Direct, energetic, concrete. Numbers over adjectives.
- On-screen text: max ~6 words per line in 9:16, ~10 in 16:9.
- Never promise results or income figures; show process and real examples.
