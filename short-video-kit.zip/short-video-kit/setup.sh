#!/usr/bin/env bash
# One-time setup on a Mac (Windows: use setup.cmd). Safe to re-run: it only installs what is missing.
#   ./setup.sh             core: FFmpeg, Node 22+, HyperFrames skills + headless Chrome
#   ./setup.sh --parakeet  also install the Parakeet transcription model (~640 MB, best for EN/FR)
#   ./setup.sh --breakdown also prepare /viral-video-breakdown now (yt-dlp, OCR, Whisper ~650 MB)
#   (flags can be combined)
set -uo pipefail
cd "$(dirname "$0")"
ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; }
warn() { printf "  \033[33m!\033[0m %s\n" "$1"; }

echo "Video editor setup"

# 1. Homebrew (needed to install the rest on macOS)
if ! command -v brew >/dev/null 2>&1 && [ "$(uname)" = "Darwin" ]; then
  warn "Homebrew not found. Install it from https://brew.sh, then re-run ./setup.sh"; exit 1
fi

# 2. FFmpeg
if command -v ffmpeg >/dev/null 2>&1; then ok "ffmpeg $(ffmpeg -version | head -1 | awk '{print $3}')"
else echo "Installing ffmpeg…"; brew install ffmpeg && ok "ffmpeg installed"; fi

# 3. Node 22+
node_major="$(node -v 2>/dev/null | sed 's/v\([0-9]*\).*/\1/')"
if [ -n "$node_major" ] && [ "$node_major" -ge 22 ]; then ok "node $(node -v)"
else
  echo "Installing Node 22…"; brew install node@22 && brew link --overwrite --force node@22 && ok "node $(node -v)"
fi

# 4. Python 3 (for scripts/vid.py and scripts/words.py — standard library only)
if command -v python3 >/dev/null 2>&1; then ok "python3 $(python3 --version | awk '{print $2}')"
else warn "python3 missing: brew install python"; fi

# 4b. yt-dlp (scripts/yt_download.py)
if command -v yt-dlp >/dev/null 2>&1 || python3 -c "import yt_dlp" >/dev/null 2>&1; then ok "yt-dlp present"
elif command -v brew >/dev/null 2>&1; then brew install yt-dlp >/dev/null && ok "yt-dlp installed"
else python3 -m pip install -q --user -U yt-dlp && ok "yt-dlp installed" || warn "run: python3 -m pip install -U yt-dlp"; fi

# 5. HyperFrames skills into this project (.claude/skills/) + headless Chrome for rendering
if [ -f .claude/skills/hyperframes/SKILL.md ]; then
  ok "HyperFrames skills present"
  npx -y hyperframes@latest skills update >/dev/null 2>&1 && ok "HyperFrames skills up to date" || warn "Could not check skill updates (offline?)"
else
  echo "Installing HyperFrames skills…"
  npx -y skills add heygen-com/hyperframes --all && ok "HyperFrames skills installed" || warn "Skill install failed — run: npx skills add heygen-com/hyperframes --all"
fi
npx -y hyperframes@latest browser ensure >/dev/null 2>&1 && ok "Headless Chrome ready" || warn "Run: npx hyperframes browser ensure"

# 6. Optional: Parakeet transcription model
if [[ " $* " == *" --parakeet "* ]]; then
  echo "Installing Parakeet (~640 MB)…"
  npx -y hyperframes@latest models install parakeet && ok "Parakeet installed" || warn "Parakeet install failed; whisper will be used instead"
else
  warn "Transcription will use whisper. For better, faster EN/FR transcripts: ./setup.sh --parakeet"
fi

# 6b. Optional: viral video breakdown env (private Python 3.12 env + OCR + Whisper)
if [[ " $* " == *" --breakdown "* ]]; then
  echo "Preparing the viral video breakdown tools (~650 MB)…"
  python3 .claude/skills/viral-video-breakdown/scripts/vidkit.py setup || warn "breakdown setup failed; Claude will retry on first use"
fi

# 7. Folders and permissions
mkdir -p projects outputs inbox library brand/assets/fonts brand/assets/avatars music

echo
npx -y hyperframes@latest doctor 2>/dev/null | tail -15 || true
echo
echo "Done. Open this folder in Claude Code and say: \"new video: <path to your clip>\""
