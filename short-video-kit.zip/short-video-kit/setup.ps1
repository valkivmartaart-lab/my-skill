# One-time setup on Windows 10/11. Safe to re-run: it only installs what is missing.
# Easiest: double-click setup.cmd. Or in PowerShell:  powershell -ExecutionPolicy Bypass -File setup.ps1 [-Parakeet] [-Breakdown]
#   -Parakeet   also install the Parakeet transcription model (~640 MB, best for English/French)
#   -Breakdown  also prepare /viral-video-breakdown now (yt-dlp, OCR, Whisper ~650 MB, in ~/.cache/vidkit);
#               otherwise Claude does it the first time you paste a TikTok/Instagram/YouTube link
param([switch]$Parakeet, [switch]$Breakdown)
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

function Ok($m)   { Write-Host "  [ok] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Refresh-Path {
  $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
}
function Has($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Install($id, $name) {
  Write-Host "Installing $name..."
  winget install --id $id -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
  Refresh-Path
}

Write-Host "Video editor setup (Windows)`n"

if (-not (Has "winget")) {
  Warn "winget not found. Install 'App Installer' from the Microsoft Store, then re-run setup."; exit 1
}

# 1. Git (Claude Code on Windows uses Git Bash to run commands)
if (Has "git") { Ok "git $(git --version)" } else { Install "Git.Git" "Git for Windows"; if (Has "git") { Ok "git installed" } else { Warn "git install failed" } }

# 2. FFmpeg (full build: includes every filter the scripts use)
if (Has "ffmpeg") { Ok "ffmpeg found" } else { Install "Gyan.FFmpeg" "FFmpeg"; if (Has "ffmpeg") { Ok "ffmpeg installed" } else { Warn "ffmpeg installed but not on PATH yet - close and reopen the terminal, then re-run setup" } }

# 3. Node.js 22+
$nodeMajor = 0
if (Has "node") { $nodeMajor = [int]((node -v) -replace '^v(\d+).*', '$1') }
if ($nodeMajor -ge 22) { Ok "node $(node -v)" } else { Install "OpenJS.NodeJS.LTS" "Node.js LTS"; if (Has "node") { Ok "node $(node -v)" } else { Warn "Node install failed" } }

# 4. Python 3 (scripts/vid.py and scripts/words.py — standard library only)
$py = $null
foreach ($c in @("python", "py")) {
  if (Has $c) { $v = & $c --version 2>&1; if ("$v" -match "Python 3") { $py = $c; break } }
}
if ($py) { Ok "$py ($(& $py --version 2>&1))" } else { Install "Python.Python.3.12" "Python 3.12"; if (Has "python") { $py = "python"; Ok "python installed" } else { Warn "Python install failed - get it from python.org (tick 'Add to PATH')" } }

# 4b. yt-dlp (scripts/yt_download.py)
if ($py) {
  & $py -m pip install -q --user -U "yt-dlp[default,curl-cffi]" 2>$null | Out-Null
  if ($LASTEXITCODE -eq 0) { Ok "yt-dlp ready" } else { Warn "yt-dlp install failed - run: $py -m pip install -U yt-dlp" }
}

# 5. HyperFrames skills into this project (.claude\skills\) + headless Chrome for rendering
if (Test-Path ".claude\skills\hyperframes\SKILL.md") {
  Ok "HyperFrames skills present"
  npx -y hyperframes@latest skills update 2>$null | Out-Null
} else {
  Write-Host "Installing HyperFrames skills (if asked which agent: Claude Code, project scope)..."
  npx -y skills add heygen-com/hyperframes --all
  if (Test-Path ".claude\skills\hyperframes\SKILL.md") { Ok "HyperFrames skills installed" } else { Warn "Skills not found in .claude\skills - run: npx skills add heygen-com/hyperframes --all" }
}
npx -y hyperframes@latest browser ensure 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Ok "Headless Chrome ready" } else { Warn "Run: npx hyperframes browser ensure" }

# 6. Optional: Parakeet transcription
if ($Parakeet) {
  Write-Host "Installing Parakeet (~640 MB)..."
  npx -y hyperframes@latest models install parakeet
} else {
  Warn "Transcription will use whisper. For better, faster EN/FR transcripts re-run with -Parakeet"
}

# 6b. Optional: viral video breakdown env (private Python 3.12 env + OCR + Whisper)
if ($Breakdown -and $py) {
  Write-Host "Preparing the viral video breakdown tools (~650 MB)..."
  & $py ".claude\skills\viral-video-breakdown\scripts\vidkit.py" setup
}

# 7. Folders
foreach ($d in @("projects", "outputs", "music", "inbox", "library", "brand\assets\fonts", "brand\assets\avatars")) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

Write-Host ""
npx -y hyperframes@latest doctor
Write-Host "`nDone. Open this folder in the Claude app (Code tab) and say: new video: <path to your clip>"
Write-Host "If a tool still isn't found, close and reopen the Claude app so it picks up the new PATH."
