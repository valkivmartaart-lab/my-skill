#!/usr/bin/env python3
"""Video editor helper — works the same on Windows and Mac. Standard library only.
Needs ffmpeg and ffprobe on PATH. Run from the project root:  python scripts/vid.py <command> …

Jobs & files
  new       <preset> <slug> <file> [file…]     create a job: projects/<date-slug>/{raw,work,comp} + job.md
  info      <file>                             duration, size, fps, audio of a media file
  open      <file|url>                         open in the default app (video player, browser…)
  finalize  <job> <rendered.mp4> [--expect-seconds N] [--srt file.srt]
                                               verify render, copy to outputs/ and Downloads (+ music credits)
  prune     <job> [--yes]                      delete heavy intermediates of an exported job

Picture & sound
  polish    <in> <out> [--lufs -16] [--denoise 12]      voice clean-up, 2-pass loudness
  grade     <in> [--out f] [--deliver] [--grain 4] [--sharpen 0.4] [--saturation 0.95] [--black 0.08] [--temp 5600]
                                               "shot on a phone" colour grade (ugc-ad footage)

Burned-in subtitles
  subs      <file> [--samples 36]              detect soft subtitle tracks + burned-in text bands;
                                               writes a contact sheet with a pixel ruler + <stem>.subs.json
  mask      <file> [--band Y1-Y2 | --scan <stem>.subs.json] [--mode black|blur|crop] [--times a-b,…] [--pad 14]
                                               cover / blur / crop out old subtitles (no --band: strip soft tracks only)

Structure
  coldopen  <cut.mp4> --start A --end B [--out f] [--words w.json --words-out w2.json] [--flash]
                                               copy the hook segment A–B to the front (it still plays in place)
  cutpoints <cut-segments.json> [--video cut.mp4] [--offset S]
                                               exact times of every join in the cut (for punch-ins / transitions)
  scenes    <broll.mp4> [--threshold 0.3]      shot list + contact sheet of a B-roll clip

Music (Jamendo, free account)
  music search [words] [--tags chill,lofi] [--instrumental] [--min 30] [--max 300] [--speed low,medium]
               [--limit 8] [--allow-nc]        search; non-commercial tracks hidden unless --allow-nc
  music open <n>                               open track n's page in the browser to listen
  music get  <n> [--job <job>]                 download track n to music/ (+ job assets) and record its credit
  config set <key> <value> | config show      local settings (jamendo_client_id, pixabay_key) in config.local.json

Stock footage (Pixabay, free key) — only when the person asks for it
  stock search <words> --job <job> [--photo] [--orientation horizontal|vertical] [--min 3] [--max 60] [--limit 12]
                                               search videos (or photos); results + numbered preview sheet
                                               in the job's work/stock-search.json/.jpg
  stock open <n> --job <job>                   open result n's page on Pixabay
  stock get  <n> --job <job>                   download result n into the job's raw/stock/ and log its source

Presets: lesson | short-explainer | short-raw | ugc-ad
"""
import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path

# Windows consoles default to cp1252 when piped; force UTF-8 so ⏸, — and accents print.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

ROOT = Path(__file__).resolve().parent.parent
PRESETS = ("lesson", "short-explainer", "short-raw", "ugc-ad")
CONFIG = ROOT / "config.local.json"
JAMENDO_BASE = os.environ.get("JAMENDO_API_BASE", "https://api.jamendo.com/v3.0")
PIXABAY_BASE = os.environ.get("PIXABAY_API_BASE", "https://pixabay.com/api")


def need(tool):
    if not shutil.which(tool):
        sys.exit(f"{tool} not found on PATH — run setup (setup.cmd on Windows) and open a new terminal.")


def run(cmd, capture=False):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        sys.exit(f"Command failed: {' '.join(map(str, cmd[:6]))}…\n{r.stderr[-2000:]}")
    return r


def probe(path):
    need("ffprobe")
    r = run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)])
    data = json.loads(r.stdout)
    v = next((s for s in data["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in data["streams"] if s["codec_type"] == "audio"), None)
    subs = [s for s in data["streams"] if s["codec_type"] == "subtitle"]
    fps = None
    if v and v.get("r_frame_rate", "0/0") != "0/0":
        n, d = v["r_frame_rate"].split("/")
        fps = round(int(n) / int(d), 2) if int(d) else None
    return {
        "duration": float(data["format"].get("duration", 0) or 0),
        "video": v["codec_name"] if v else None,
        "size": f"{v['width']}x{v['height']}" if v and "width" in v else None,
        "fps": fps,
        "audio": a["codec_name"] if a else None,
        "subtitle_tracks": [
            {"index": s["index"], "codec": s.get("codec_name"), "language": s.get("tags", {}).get("language")}
            for s in subs
        ],
    }


def wh(p):
    w, h = p["size"].split("x")
    return int(w), int(h)


def work_dir_for(path):
    """Outputs for a file in projects/<job>/raw/ go to projects/<job>/work/ (raw/ is never written)."""
    p = Path(path).resolve()
    if p.parent.name == "raw" and (p.parent.parent / "work").is_dir():
        return p.parent.parent / "work"
    return p.parent


def fmt_t(t):
    m, s = divmod(max(0.0, t), 60)
    return f"{int(m)}:{s:04.1f}"


ENCODE_V = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p"]

FONT_CANDIDATES = [
    "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/segoeui.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf", "/Library/Fonts/Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans.ttf",
]


def find_font():
    return next((f for f in FONT_CANDIDATES if Path(f).is_file()), None)


def ff_path(p):
    """Escape a file path for use inside an ffmpeg filter argument (Windows drive colons)."""
    return str(p).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")


def make_sheet(src, times, labels, out, grid_src_h=None):
    """Contact sheet: one tile per time, label top-left; optional horizontal ruler (source-pixel y labels)."""
    p = probe(src)
    w0, h0 = wh(p)
    portrait = h0 > w0
    tile_w, cols = (240, 6) if portrait else (400, 3)
    font = find_font()
    tmp = Path(tempfile.mkdtemp(prefix="vid-sheet-"))
    try:
        for i, (t, label) in enumerate(zip(times, labels)):
            t = min(max(0.0, t), max(0.0, p["duration"] - 0.06))
            base = [f"scale={tile_w}:-2"]
            if grid_src_h:
                for k in range(1, 10):
                    base.append(f"drawbox=x=0:y=ih*{k}/10:w=iw:h={2 if k == 5 else 1}:"
                                f"color={'red' if k == 5 else 'yellow'}@0.85:t=fill")
            text = []
            if font:
                fe = ff_path(font)
                safe = re.sub(r"[^A-Za-z0-9 #.\-]", "", label)
                text.append(f"drawtext=fontfile='{fe}':text='{safe}':x=4:y=4:fontsize=15:"
                            f"fontcolor=white:box=1:boxcolor=black@0.65:boxborderw=3")
                if grid_src_h:
                    for k in range(1, 10):
                        text.append(f"drawtext=fontfile='{fe}':text='{int(grid_src_h * k / 10)}':"
                                    f"x=w-tw-3:y=h*{k}/10-th-2:fontsize=11:fontcolor=yellow:"
                                    f"box=1:boxcolor=black@0.55:boxborderw=1")
            target = tmp / f"{i:04d}.png"
            for vf in ([*base, *text], base):  # retry without labels if fonts are unavailable
                r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t:.3f}",
                                    "-i", str(src), "-frames:v", "1", "-vf", ",".join(vf), str(target)],
                                   capture_output=True, text=True, encoding="utf-8", errors="replace")
                if r.returncode == 0 and target.is_file():
                    break
            else:
                sys.exit(f"Could not extract a frame at {t:.2f}s from {src}:\n{r.stderr[-800:]}")
        rows = -(-len(times) // cols)
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-framerate", "1", "-i", str(tmp / "%04d.png"),
             "-vf", f"tile={cols}x{rows}:padding=4:margin=4:color=0x222222", "-frames:v", "1", str(out)])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return out


def scene_scores(src):
    """Per-frame scene-change score (0–1) and time, computed by ffmpeg on a small proxy."""
    need("ffmpeg")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-loglevel", "info", "-i", str(src), "-an", "-sn",
                        "-vf", "scale=96:-2,select='gte(scene,0)',metadata=print", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    out, t = [], None
    for line in r.stderr.splitlines():
        m = re.search(r"pts_time:([\d.eE+-]+)", line)
        if m:
            t = float(m.group(1))
            continue
        m = re.search(r"lavfi\.scene_score=([\d.eE+-]+)", line)
        if m and t is not None:
            out.append((t, float(m.group(1))))
            t = None
    if not out:
        sys.exit(f"Could not read scene scores from {src}:\n{r.stderr[-800:]}")
    return out


# ---------------------------------------------------------------- new
def cmd_new(a):
    if a.preset not in PRESETS:
        sys.exit(f"Unknown preset '{a.preset}' ({' | '.join(PRESETS)})")
    slug = re.sub(r"[^a-z0-9-]", "", a.slug.lower().replace(" ", "-").replace("_", "-"))
    job = f"{dt.date.today():%Y-%m-%d}-{slug}"
    d = ROOT / "projects" / job
    if d.exists():
        sys.exit(f"Job {job} already exists: {d}")
    for f in a.files:
        if not Path(f).is_file():
            sys.exit(f"Not a file: {f}")
    for sub in ("raw", "work", "comp"):
        (d / sub).mkdir(parents=True)
    lines = []
    for f in a.files:
        dest = d / "raw" / Path(f).name
        shutil.copy2(f, dest)
        try:
            p = probe(dest)
            lines.append(f"- `raw/{dest.name}` — {p['duration']:.0f}s {p['size'] or 'audio/image'} — role: ?")
        except SystemExit:
            lines.append(f"- `raw/{dest.name}` — role: ?")
    (d / "job.md").write_text(
        f"""# Job: {job}

- Preset: `{a.preset}` (see presets/formats.md)
- Created: {dt.datetime.now():%Y-%m-%d %H:%M}
- Language: en

## Raw files
(role = main take · B-roll · avatar shot · music · other)
{chr(10).join(lines) or '- (none yet — drop files into raw/)'}

## Footage notes
- Burned-in subtitles: not scanned yet
- Hook (cold open): none yet
- B-roll: none

## Status
- [ ] 1. Rough cut / assemble (incl. subtitle scan, hook)
- [ ] 2. Graphics (plan approved: no) — incl. B-roll cutaways, punch-ins, transitions
- [ ] 3. Captions
- [ ] 4. Finish & export (music + credits)

## Decisions
- (Claude: log what the person decided at each step — cut choices kept, hook, music track/level/credit, style changes to keep)
""",
        encoding="utf-8",
    )
    print(job)


# ---------------------------------------------------------------- info / open
def cmd_info(a):
    print(json.dumps(probe(a.file), indent=1))


def cmd_open(a):
    target = a.file
    if re.match(r"^https?://", target):
        webbrowser.open(target)
        print(f"Opened {target}")
        return
    path = str(Path(target).resolve())
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa — Windows only
    elif sys.platform == "darwin":
        subprocess.run(["open", path])
    else:
        subprocess.run(["xdg-open", path])
    print(f"Opened {path}")


# ---------------------------------------------------------------- polish
def cmd_polish(a):
    need("ffmpeg")
    pre = "highpass=f=80"
    if a.denoise > 0:
        pre += f",afftdn=nr={a.denoise}:nf=-30"
    target = f"I={a.lufs}:TP=-1.5:LRA=11"
    r = subprocess.run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", a.input, "-af", f"{pre},loudnorm={target}:print_format=json", "-f", "null", "-"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr)
    if not m:
        sys.exit("Could not measure loudness:\n" + r.stderr[-1500:])
    s = json.loads(m.group(0))
    norm = (f"loudnorm={target}:measured_I={s['input_i']}:measured_TP={s['input_tp']}:"
            f"measured_LRA={s['input_lra']}:measured_thresh={s['input_thresh']}:offset={s['target_offset']}:linear=true")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", a.input]
    if probe(a.input)["video"]:
        cmd += ["-map", "0:v:0", "-c:v", "copy"]
    cmd += ["-map", "0:a:0", "-af", f"{pre},{norm}", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-movflags", "+faststart", a.output]
    run(cmd)
    print(f"{a.output} (input {s['input_i']} LUFS -> {a.lufs} LUFS)")


# ---------------------------------------------------------------- grade
def cmd_grade(a):
    need("ffmpeg")
    src = Path(a.input)
    if src.stem.endswith("-graded"):
        sys.exit(f"Refusing: {src} looks already graded (never grade twice)")
    out = a.out or str(work_dir_for(src) / (src.stem + "-graded.mp4"))
    f = [
        f"eq=saturation={a.saturation}:contrast=1.10:brightness=-0.025",
        f"colortemperature=temperature={a.temp}",
        "hue=h=3",
        "colorbalance=rs=-0.02:bs=0.04:rm=-0.015:bm=0.035:rh=-0.025:bh=0.025",
        f"curves=all='0/{a.black} 0.30/0.35 0.70/0.70 1/0.94'",
    ]
    if a.sharpen:
        f.append(f"unsharp=5:5:{a.sharpen}:5:5:0")  # luma only
    if a.grain:
        f.append(f"noise=alls={a.grain}:allf=t")
    if a.deliver:
        f.append("scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black")
        f.append("fps=60")  # frame duplication only — never optical-flow interpolation (warps hands and faces)
    f.append("scale=out_color_matrix=bt709:out_range=tv,format=yuv420p")
    audio = ["-c:a", "aac", "-b:a", "192k"] if probe(src)["audio"] else ["-an"]
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-sn", "-vf", ",".join(f),
         "-c:v", "libx264", "-profile:v", "high", "-preset", "veryfast", "-crf", "17",
         "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
         *audio, "-movflags", "+faststart", out])
    print(out)


# ---------------------------------------------------------------- subs (detect)
def _gray_samples(src, n, width=240):
    p = probe(src)
    w0, h0 = wh(p)
    h = max(2, int(round(h0 * width / w0 / 2)) * 2)
    dur = p["duration"] or 1.0
    rate = n / dur
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(src), "-an", "-sn",
                        "-vf", f"fps={rate:.6f},scale={width}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    if r.returncode != 0:
        sys.exit("Could not sample frames:\n" + r.stderr.decode("utf-8", "replace")[-800:])
    fs = width * h
    frames = [r.stdout[i:i + fs] for i in range(0, len(r.stdout) - fs + 1, fs)]
    return frames, [i / rate for i in range(len(frames))], width, h, p, dur


def _row_scores(fr, w, h, thr=40):
    """Fraction of strong horizontal transitions per row — text rows light up, faces and skies don't."""
    out = []
    for y in range(h):
        row = fr[y * w:(y + 1) * w]
        out.append(sum(1 for x in range(1, w) if abs(row[x] - row[x - 1]) > thr) / w)
    return out


def _runs(flags, maxgap=2):
    bands, start, end, gap = [], None, None, 0
    for y, f in enumerate(flags):
        if f:
            if start is None:
                start = y
            end, gap = y, 0
        elif start is not None:
            gap += 1
            if gap > maxgap:
                bands.append((start, end))
                start, gap = None, 0
    if start is not None:
        bands.append((start, end))
    return bands


def _merge_times(present, times, half, dur):
    ranges, cur = [], None
    for ok, t in zip(present, times):
        if ok:
            s, e = max(0.0, t - half), min(dur, t + half)
            if cur and s <= cur[1] + 0.01:
                cur[1] = e
            else:
                if cur:
                    ranges.append(cur)
                cur = [s, e]
    if cur:
        ranges.append(cur)
    return [[round(s, 2), round(e, 2)] for s, e in ranges]


def cmd_subs(a):
    need("ffmpeg")
    src = Path(a.file)
    frames, times, w, h, p, dur = _gray_samples(src, a.samples)
    W0, H0 = wh(p)
    n = len(frames)
    if n < 2:
        sys.exit("Video too short to scan.")
    min_h, max_h = max(2, int(0.012 * h)), int(0.20 * h)
    frame_flags = []
    for fr in frames:
        sc = _row_scores(fr, w, h)
        smooth = [(sc[max(0, y - 1)] + sc[y] + sc[min(h - 1, y + 1)]) / 3 for y in range(h)]
        flags = [False] * h
        for y0, y1 in _runs([v >= 0.10 for v in smooth]):
            if min_h <= y1 - y0 + 1 <= max_h:
                for y in range(y0, y1 + 1):
                    flags[y] = True
        frame_flags.append(flags)
    frac = [sum(ff[y] for ff in frame_flags) / n for y in range(h)]
    bands = []
    for y0, y1 in _runs([f >= 0.15 for f in frac], maxgap=3):
        if y1 - y0 + 1 < min_h:
            continue
        present = [any(ff[y] for y in range(y0, y1 + 1)) for ff in frame_flags]
        # Does the band change more than the rest of the picture? (subtitle lines change, textures don't)
        bd, rd = [], []
        for i in range(1, n):
            f1, f2 = frames[i - 1], frames[i]
            band_px = range(y0 * w, (y1 + 1) * w, 2)
            rest_px = [k for k in range(0, w * h, 7) if not (y0 * w <= k < (y1 + 1) * w)]
            bd.append(sum(abs(f1[k] - f2[k]) for k in band_px) / max(1, len(band_px)))
            rd.append(sum(abs(f1[k] - f2[k]) for k in rest_px) / max(1, len(rest_px)))
        ratio = (sum(bd) / len(bd) + 1) / (sum(rd) / len(rd) + 1)
        coverage = sum(present) / n
        sy0, sy1 = int(y0 * H0 / h), int((y1 + 1) * H0 / h)
        bands.append({
            "y0": sy0, "y1": sy1, "pct": f"{100 * sy0 / H0:.0f}–{100 * sy1 / H0:.0f}%",
            "coverage": round(coverage, 2), "change_ratio": round(ratio, 2),
            "likely_subtitles": coverage >= 0.15 and ratio >= 1.3,
            "in_safe_zone_9x16": (H0 > W0 and sy0 >= 168 * H0 / 1920 and sy1 <= 1330 * H0 / 1920),
            "times": _merge_times(present, times, dur / n / 2 + 0.05, dur),
        })
    bands.sort(key=lambda b: (not b["likely_subtitles"], -b["coverage"]))
    bands = bands[:4]

    wd = work_dir_for(src)
    sheet = wd / f"{src.stem}.subs-sheet.png"
    k = min(12, n)
    pick = [int(i * n / k) for i in range(k)]
    make_sheet(src, [times[i] + 0.01 for i in pick], [f"{times[i]:.1f}s" for i in pick], sheet, grid_src_h=H0)
    result = {"file": str(src), "size": p["size"], "duration": round(dur, 2),
              "soft_tracks": p["subtitle_tracks"], "bands": bands, "sheet": str(sheet)}
    js = wd / f"{src.stem}.subs.json"
    js.write_text(json.dumps(result, indent=1), encoding="utf-8")

    print(f"Soft subtitle tracks: {len(p['subtitle_tracks']) or 'none'}"
          + (" → strip with: python scripts/vid.py mask <file>" if p["subtitle_tracks"] else ""))
    likely = [b for b in bands if b["likely_subtitles"]]
    if not bands:
        print("Burned-in text: none detected.")
    for b in bands:
        tag = "LIKELY SUBTITLES" if b["likely_subtitles"] else "text-like band (check visually)"
        print(f"- {tag}: y={b['y0']}–{b['y1']} px ({b['pct']}), on screen {int(b['coverage'] * 100)}% of samples, "
              f"change ratio {b['change_ratio']}" + ("" if H0 <= W0 else f", inside 9:16 safe zone: {b['in_safe_zone_9x16']}"))
    if likely:
        print(f"Suggested: python scripts/vid.py mask \"{src}\" --scan \"{js}\"")
    print(f"Contact sheet (yellow ruler lines every 10% with source y in px, red = middle): {sheet}")
    print("Always confirm on the sheet before masking — the detector flags any dense text, not only subtitles.")


# ---------------------------------------------------------------- mask
def _parse_band(s, H):
    pct = "%" in s
    a_, b_ = [float(x) for x in s.replace("%", "").split("-", 1)]
    if pct:
        return int(a_ / 100 * H), int(b_ / 100 * H)
    if b_ <= 1.0:
        return int(a_ * H), int(b_ * H)
    return int(a_), int(b_)


def cmd_mask(a):
    need("ffmpeg")
    src = Path(a.input)
    p = probe(src)
    W, H = wh(p)
    out = Path(a.out) if a.out else work_dir_for(src) / f"{src.stem}-nosubs.mp4"
    band, times = a.band, a.times
    if a.scan and not band:
        scan = json.loads(Path(a.scan).read_text(encoding="utf-8"))
        likely = [b for b in scan["bands"] if b["likely_subtitles"]] or scan["bands"]
        if not likely:
            sys.exit("The scan found no text band; pass --band Y1-Y2 if you can see subtitles on the sheet.")
        b = likely[0]
        band = f"{b['y0']}-{b['y1']}"
        if not times and b["coverage"] < 0.85:
            times = ",".join(f"{s}-{e}" for s, e in b["times"])
    audio = ["-map", "0:a:0", "-c:a", "copy"] if p["audio"] else []
    if not band:
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-map", "0", "-map", "-0:s",
             "-c", "copy", str(out)])
        print(f"{out} — soft subtitle tracks removed ({len(p['subtitle_tracks'])}), picture untouched")
        return
    y0, y1 = _parse_band(band, H)
    y0, y1 = max(0, y0 - a.pad), min(H, y1 + a.pad)
    y0 -= y0 % 2
    y1 += y1 % 2
    bh = y1 - y0
    enable = ""
    if times and a.mode != "crop":
        expr = "+".join(f"between(t,{float(s)},{float(e)})" for s, e in (r.split("-") for r in times.split(",")))
        enable = f":enable='{expr}'"
    if a.mode == "black":
        fc = f"[0:v]drawbox=x=0:y={y0}:w=iw:h={bh}:color=black@1:t=fill{enable}[v]"
    elif a.mode == "blur":
        lr = max(2, min(20, bh // 2 - 1))
        cr = max(1, min(10, bh // 4 - 1))
        fc = (f"[0:v]split[a][b];[b]crop=iw:{bh}:0:{y0},boxblur=luma_radius={lr}:luma_power=5:"
              f"chroma_radius={cr}:chroma_power=5[bl];[a][bl]overlay=0:{y0}{enable}[v]")
    else:  # crop: push in so the band leaves the frame, keep the canvas size
        if y0 >= H * 0.5:
            nh, cy = y0, 0
        elif y1 <= H * 0.5:
            nh, cy = H - y1, y1
        else:
            sys.exit("Band crosses the middle of the frame — crop would lose the subject. Use --mode black or blur.")
        nh -= nh % 2
        cw = int(W * nh / H)
        cw -= cw % 2
        zoom = H / nh
        if zoom > 1.35:
            print(f"Warning: crop zooms {zoom:.2f}× — visible softness likely; black band may look better.")
        fc = f"[0:v]crop={cw}:{nh}:{(W - cw) // 2}:{cy},scale={W}:{H}:flags=lanczos,setsar=1[v]"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-filter_complex", fc,
         "-map", "[v]", *audio, "-sn", *ENCODE_V, "-movflags", "+faststart", str(out)])
    what = {"black": "covered with a black band", "blur": "blurred", "crop": "cropped out"}[a.mode]
    print(f"{out} — y={y0}–{y1} px {what}" + (f" during {times}" if enable else "")
          + ("" if a.mode == "crop" else f". Place captions centred at y≈{(y0 + y1) // 2} px (band height {bh} px)."))


# ---------------------------------------------------------------- coldopen
def cmd_coldopen(a):
    need("ffmpeg")
    src = Path(a.input)
    p = probe(src)
    s, e, dur = a.start, a.end, p["duration"]
    if not (0 <= s < e <= dur + 0.01):
        sys.exit(f"Hook {s}-{e}s is outside the video (0–{dur:.2f}s)")
    hd = e - s
    if hd < 0.6:
        sys.exit("Hook shorter than 0.6 s — pick a complete phrase.")
    if hd > 6:
        print(f"Note: hook is {hd:.1f}s — over ~4 s it stops feeling like a cold open.")
    out = Path(a.out) if a.out else src.with_name(src.stem + "-hook.mp4")
    # The source is opened twice (input 0 = hook only, input 1 = body) rather than split once:
    # split would buffer every body frame decoded while the hook is still playing — out of memory on 1080p.
    vh = f"[0:v]trim=start={s}:end={e},setpts=PTS-STARTPTS"
    vb = "[1:v]setpts=PTS-STARTPTS"
    if a.flash:  # white "zap" at the seam: hook flashes out, body fades in from white
        vh += f",fade=t=out:st={max(0.0, hd - 0.08):.3f}:d=0.08:color=white"
        vb += ",fade=t=in:st=0:d=0.18:color=white"
    fc = f"{vh}[hv];{vb}[bv];"
    if p["audio"]:
        f = 0.03
        fc += (f"[0:a]atrim=start={s}:end={e},asetpts=PTS-STARTPTS,afade=t=in:st=0:d={f},afade=t=out:st={hd - f:.3f}:d={f}[ha];"
               f"[1:a]asetpts=PTS-STARTPTS,afade=t=in:st=0:d={f}[ba];[hv][ha][bv][ba]concat=n=2:v=1:a=1[v][a]")
        maps = ["-map", "[v]", "-map", "[a]", "-c:a", "aac", "-b:a", "192k"]
    else:
        fc += "[hv][bv]concat=n=2:v=1:a=0[v]"
        maps = ["-map", "[v]"]
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-t", f"{e + 0.5:.3f}", "-i", str(src),
         "-i", str(src), "-filter_complex", fc,
         *maps, "-sn", *ENCODE_V, "-movflags", "+faststart", str(out)])
    if a.words:
        data = json.loads(Path(a.words).read_text(encoding="utf-8"))
        words = data["words"] if isinstance(data, dict) else data
        hook = []
        for w in words:
            if w["start"] >= s - 0.05 and w["start"] < e - 0.05:  # a last word running past the cut still counts
                hook.append(dict(w, start=round(max(0.0, w["start"] - s), 3), end=round(min(hd, w["end"] - s), 3)))
        body = [dict(w, start=round(w["start"] + hd, 3), end=round(w["end"] + hd, 3)) for w in words]
        merged = hook + body
        if merged and "id" in merged[0]:
            for i, w in enumerate(merged):
                w["id"] = f"w{i}"
        if isinstance(data, dict):
            data = dict(data, words=merged)
            if "text" in data:
                data["text"] = " ".join(str(w.get("text", w.get("word", ""))) for w in merged)
        else:
            data = merged
        wout = Path(a.words_out) if a.words_out else Path(a.words).with_name(Path(a.words).stem + "-hook.json")
        wout.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"{wout} — {len(hook)} hook words + {len(body)} words shifted by {hd:.3f}s (no re-transcription needed)")
    print(f"{out} — hook {s:.2f}–{e:.2f}s copied to the front ({hd:.2f}s); seam at {hd:.2f}s; "
          f"new length {dur + hd:.2f}s" + (" (white flash at the seam)" if a.flash else ""))


# ---------------------------------------------------------------- cutpoints
def cmd_cutpoints(a):
    segs = json.loads(Path(a.segments).read_text(encoding="utf-8"))
    if isinstance(segs, dict):
        segs = segs.get("segments") or segs.get("kept") or []
    if not segs:
        sys.exit("No segments in that file (save the output of transcript-cut --plan).")
    pred, acc = [], a.offset
    if a.offset > 0:
        pred.append(a.offset)
    for sg in segs[:-1]:
        acc += sg["end"] - sg["start"]
        pred.append(acc)
    total = acc + segs[-1]["end"] - segs[-1]["start"]
    cuts = [round(t, 3) for t in pred]
    snapped = 0
    if a.video:
        scores = scene_scores(a.video)
        total = probe(a.video)["duration"]
        cuts = []
        for i, t in enumerate(pred):
            if i == 0 and a.offset > 0:  # the cold-open seam is known exactly — never snap it
                cuts.append(round(t, 3))
                continue
            win = [(tt, sc) for tt, sc in scores if abs(tt - t) <= a.window]
            if win:
                vals = sorted(sc for _, sc in win)
                med = vals[len(vals) // 2]
                tt, best = max(win, key=lambda x: x[1])
                if best >= max(0.004, 2.5 * med):
                    cuts.append(round(tt, 3))
                    snapped += 1
                    continue
            cuts.append(round(t, 3))
    gaps = [round(b - a_, 2) for a_, b in zip([0.0] + cuts, cuts + [total])]
    print(json.dumps({"cuts": cuts, "segment_lengths": gaps, "total": round(total, 3),
                      "seam": round(a.offset, 3) if a.offset > 0 else None,
                      "snapped_to_frames": snapped if a.video else "no --video given (predicted times)"}, indent=1))


# ---------------------------------------------------------------- scenes
def cmd_scenes(a):
    src = Path(a.file)
    p = probe(src)
    scores = scene_scores(src)
    dur = p["duration"]
    bounds = [0.0]
    for t, sc in scores:
        if sc >= a.threshold and t - bounds[-1] >= a.min_len:
            bounds.append(t)
    if dur - bounds[-1] < a.min_len and len(bounds) > 1:
        bounds.pop()
    shots = [{"n": i + 1, "start": round(s, 2), "end": round(e, 2), "length": round(e - s, 2)}
             for i, (s, e) in enumerate(zip(bounds, bounds[1:] + [dur]))]
    sheet = work_dir_for(src) / f"{src.stem}.shots.png"
    show = shots[:24]
    make_sheet(src, [(s["start"] + s["end"]) / 2 for s in show],
               [f"#{s['n']} {s['start']:.1f}-{s['end']:.1f}s" for s in show], sheet)
    print(f"{src.name}: {p['size']}, {dur:.1f}s, audio: {p['audio'] or 'none'}, {len(shots)} shot(s)")
    for s in shots:
        print(f"  #{s['n']:<2} {s['start']:6.2f}–{s['end']:6.2f}s  ({s['length']:.1f}s)")
    print(f"Contact sheet (middle frame of each shot): {sheet}")


# ---------------------------------------------------------------- config
def load_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def cmd_config(a):
    cfg = load_config()
    if a.action == "set":
        if not a.key or a.value is None:
            sys.exit("Usage: config set <key> <value>")
        cfg[a.key] = a.value
        CONFIG.write_text(json.dumps(cfg, indent=1), encoding="utf-8")
        print(f"Saved {a.key} in {CONFIG.name} (local only — never shared or committed)")
    else:
        for k, v in cfg.items():
            v = str(v)
            print(f"{k}: {v[:4] + '…' + v[-2:] if len(v) > 8 else '***'}")
        if not cfg:
            print("(no local settings)")


# ---------------------------------------------------------------- music
def _license(url):
    u = (url or "").lower()
    if "publicdomain" in u:
        return "CC0", True, False
    m = re.search(r"/licenses/([a-z-]+)/", u)
    code = m.group(1) if m else "?"
    parts = code.split("-")
    return "CC " + code.upper(), "nc" not in parts, True


def _jamendo_id():
    cid = os.environ.get("JAMENDO_CLIENT_ID") or load_config().get("jamendo_client_id")
    if not cid:
        sys.exit("No Jamendo client ID yet. It's free: sign in at https://devportal.jamendo.com, create an app, "
                 "copy its Client ID, then run:\n  python scripts/vid.py config set jamendo_client_id <ID>")
    return cid


def _http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "video-editor/1.1"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        sys.exit(f"Request to {urllib.parse.urlparse(url).netloc} failed: {e}")


def _cache():
    return ROOT / "music" / ".last-search.json"


def cmd_music(a):
    if a.mcmd == "search":
        params = {"client_id": _jamendo_id(), "format": "json", "limit": min(200, a.limit * 4),
                  "include": "musicinfo licenses", "audioformat": "mp32", "audiodlformat": "mp32",
                  "boost": "popularity_total", "durationbetween": f"{a.min}_{a.max}"}
        if a.words:
            params["search"] = " ".join(a.words)
        if a.tags:
            params["fuzzytags"] = " ".join(t.strip() for t in a.tags.split(",") if t.strip())
        if a.instrumental:
            params["vocalinstrumental"] = "instrumental"
        if a.speed:
            params["speed"] = " ".join(s.strip() for s in a.speed.split(","))
        data = _http_json(f"{JAMENDO_BASE}/tracks/?{urllib.parse.urlencode(params)}")
        hdr = data.get("headers", {})
        if hdr.get("code", 0) not in (0, "0") or hdr.get("status") == "failed":
            sys.exit(f"Jamendo error: {hdr.get('error_message') or hdr}")
        tracks, hidden = [], 0
        for t in data.get("results", []):
            lic, commercial, attribution = _license(t.get("license_ccurl"))
            if not t.get("audiodownload_allowed", True) or not t.get("audiodownload"):
                continue
            if not commercial and not a.allow_nc:
                hidden += 1
                continue
            tags = t.get("musicinfo", {}).get("tags", {})
            tracks.append({
                "id": t["id"], "name": t.get("name", "?"), "artist": t.get("artist_name", "?"),
                "duration": int(t.get("duration", 0) or 0), "license": lic, "license_url": t.get("license_ccurl"),
                "commercial_ok": commercial, "attribution": attribution,
                "tags": (tags.get("genres", []) + tags.get("vartags", []) + tags.get("instruments", []))[:5],
                "vocal": t.get("musicinfo", {}).get("vocalinstrumental"),
                "page": t.get("shareurl") or f"https://www.jamendo.com/track/{t['id']}",
                "download": t["audiodownload"],
            })
            if len(tracks) >= a.limit:
                break
        _cache().parent.mkdir(exist_ok=True)
        _cache().write_text(json.dumps(tracks, indent=1), encoding="utf-8")
        if not tracks:
            print("No downloadable tracks matched. Try fewer tags or a wider --min/--max.")
        for i, t in enumerate(tracks, 1):
            m, s = divmod(t["duration"], 60)
            flag = "commercial OK" if t["commercial_ok"] else "NON-COMMERCIAL ONLY"
            print(f"{i:>2}. {t['name']} — {t['artist']}  [{m}:{s:02d}]  {t['license']} ({flag}"
                  f"{', credit required' if t['attribution'] else ''})  {', '.join(t['tags'])}")
            print(f"    listen: {t['page']}")
        if hidden:
            print(f"({hidden} non-commercial track(s) hidden — add --allow-nc for course-only/non-commercial use)")
        return
    tracks = json.loads(_cache().read_text(encoding="utf-8")) if _cache().is_file() else []
    if not tracks:
        sys.exit("Run 'music search' first.")
    if not 1 <= a.n <= len(tracks):
        sys.exit(f"Pick a number between 1 and {len(tracks)}.")
    t = tracks[a.n - 1]
    if a.mcmd == "open":
        webbrowser.open(t["page"])
        print(f"Opened {t['page']}")
        return
    safe = re.sub(r'[<>:"/\\|?*]+', "", f"{t['artist']} - {t['name']}").strip()[:80]
    dest = ROOT / "music" / f"{safe} [jamendo-{t['id']}].mp3"
    if not dest.is_file():
        req = urllib.request.Request(t["download"], headers={"User-Agent": "video-editor/1.1"})
        tmp = dest.with_suffix(".part")
        try:
            with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as fh:
                shutil.copyfileobj(r, fh)
        except Exception as e:
            tmp.unlink(missing_ok=True)
            sys.exit(f"Download failed: {e}")
        tmp.replace(dest)
    credit = (f'Music: "{t["name"]}" by {t["artist"]} ({t["license"]}, {t["license_url"]}) — via Jamendo {t["page"]}'
              if t["attribution"] else f'Music: "{t["name"]}" by {t["artist"]} (CC0) — via Jamendo')
    credits_all = ROOT / "music" / "CREDITS.txt"
    existing = credits_all.read_text(encoding="utf-8") if credits_all.is_file() else ""
    if credit not in existing:
        with credits_all.open("a", encoding="utf-8") as fh:
            fh.write(credit + "\n")
    print(f"{dest}")
    if a.job:
        jd = ROOT / "projects" / a.job
        if not jd.is_dir():
            sys.exit(f"No job {a.job}")
        (jd / "comp" / "assets" / "music").mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, jd / "comp" / "assets" / "music" / dest.name)
        jc = jd / "work" / "music-credits.txt"
        jc.parent.mkdir(exist_ok=True)
        jc.write_text(credit + "\n", encoding="utf-8")
        print(f"Copied to {jd / 'comp' / 'assets' / 'music' / dest.name}; credit saved in {jc}")
    print(credit)
    if not t["commercial_ok"]:
        print("⚠ Non-commercial license: fine for the course itself, NOT for ads or paid promotion.")


# ---------------------------------------------------------------- stock (Pixabay)
def _pixabay_key():
    key = os.environ.get("PIXABAY_KEY") or load_config().get("pixabay_key")
    if not key:
        sys.exit("No Pixabay key yet. It's free: sign in at https://pixabay.com/api/docs/, copy your key, then run:\n"
                 "  python scripts/vid.py config set pixabay_key <KEY>")
    return key


def _stock_cache(job):
    """Search results live in the job, so jobs edited in parallel never pick from each other's list."""
    jd = ROOT / "projects" / job
    if not jd.is_dir():
        sys.exit(f"No job {job}")
    (jd / "work").mkdir(exist_ok=True)
    return jd / "work" / "stock-search.json"


def _download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "video-editor/1.1"})
    tmp = dest.with_name(dest.name + ".part")
    try:
        with urllib.request.urlopen(req, timeout=180) as r, open(tmp, "wb") as fh:
            shutil.copyfileobj(r, fh)
    except Exception as e:
        tmp.unlink(missing_ok=True)
        sys.exit(f"Download failed: {e}")
    tmp.replace(dest)


def _stock_sheet(items, out):
    """Numbered preview sheet of the search results, so they can be judged by eye before downloading."""
    font = find_font()
    tmp = Path(tempfile.mkdtemp(prefix="vid-stock-"))
    try:
        n = 0
        for i, it in enumerate(items, 1):
            thumb = tmp / f"t{i}.jpg"
            try:
                _download(it["preview"], thumb)
            except SystemExit:
                continue
            vf = "scale=320:180:force_original_aspect_ratio=decrease,pad=320:180:(ow-iw)/2:(oh-ih)/2:color=0x222222"
            label = f"{i}  {it['duration']}s" if it["kind"] == "video" else f"{i}  photo"
            if font:
                vf += (f",drawtext=fontfile='{ff_path(font)}':text='{label}':x=4:y=4:fontsize=18:"
                       f"fontcolor=white:box=1:boxcolor=black@0.7:boxborderw=3")
            r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(thumb), "-vf", vf,
                                str(tmp / f"{n:04d}.png")], capture_output=True)
            if r.returncode == 0:
                n += 1
        if not n:
            return None
        cols = min(4, n)
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-framerate", "1", "-i", str(tmp / "%04d.png"),
             "-vf", f"tile={cols}x{-(-n // cols)}:padding=4:margin=4:color=0x111111", "-frames:v", "1", str(out)])
        return out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_stock(a):
    if a.scmd == "search":
        params = {"key": _pixabay_key(), "q": " ".join(a.words)[:100], "safesearch": "true",
                  "per_page": max(3, min(200, a.limit * 2)), "order": "popular"}
        if a.photo:
            params.update(image_type="photo")
            if a.orientation:
                params["orientation"] = a.orientation
        data = _http_json(f"{PIXABAY_BASE}/{'' if a.photo else 'videos/'}?{urllib.parse.urlencode(params)}")
        items = []
        for h in data.get("hits", []):
            if a.photo:
                items.append({"kind": "photo", "id": h["id"], "tags": h.get("tags", ""), "user": h.get("user", "?"),
                              "page": h.get("pageURL"), "size": f"{h.get('imageWidth')}x{h.get('imageHeight')}",
                              "duration": 0, "preview": h.get("webformatURL") or h.get("previewURL"),
                              "download": h.get("largeImageURL") or h.get("webformatURL")})
            else:
                v = h.get("videos", {})
                sizes = [v[k] for k in ("large", "medium", "small") if v.get(k, {}).get("url")]
                # largest file no wider/taller than 1920 px: plenty for a 1080x1920 render, a fraction of 4K's size
                best = next((s for s in sizes if max(s["width"], s["height"]) <= 1920), sizes[-1] if sizes else None)
                if not best or not a.min <= h.get("duration", 0) <= a.max:
                    continue
                if a.orientation and (best["width"] >= best["height"]) != (a.orientation == "horizontal"):
                    continue
                items.append({"kind": "video", "id": h["id"], "tags": h.get("tags", ""), "user": h.get("user", "?"),
                              "page": h.get("pageURL"), "size": f"{best['width']}x{best['height']}",
                              "duration": h.get("duration", 0),
                              "preview": (v.get("medium") or best).get("thumbnail") or best.get("thumbnail"),
                              "download": best["url"]})
            if len(items) >= a.limit:
                break
        cache = _stock_cache(a.job)
        cache.write_text(json.dumps(items, indent=1), encoding="utf-8")
        if not items:
            print("Nothing matched. Try shorter, more concrete words (\"goalkeeper\", \"microphone stage\").")
            return
        for i, it in enumerate(items, 1):
            extra = f"{it['duration']}s " if it["kind"] == "video" else ""
            tags = ", ".join(dict.fromkeys(t.strip() for t in it["tags"].split(",")))
            print(f"{i:>2}. {it['kind']} {extra}{it['size']}  {tags[:90]}  — by {it['user']}")
            print(f"    {it['page']}")
        sheet = _stock_sheet(items, cache.with_suffix(".jpg"))
        if sheet:
            print(f"Preview sheet (numbers match the list): {sheet}")
        print("Pixabay Content License: free for commercial use, no credit required.")
        return
    cache = _stock_cache(a.job)
    items = json.loads(cache.read_text(encoding="utf-8")) if cache.is_file() else []
    if not items:
        sys.exit(f"Run 'stock search … --job {a.job}' first.")
    if not 1 <= a.n <= len(items):
        sys.exit(f"Pick a number between 1 and {len(items)}.")
    it = items[a.n - 1]
    if a.scmd == "open":
        webbrowser.open(it["page"])
        print(f"Opened {it['page']}")
        return
    jd = ROOT / "projects" / a.job
    if not jd.is_dir():
        sys.exit(f"No job {a.job}")
    words = re.sub(r"[^a-z0-9]+", "-", it["tags"].split(",")[0].lower()).strip("-")[:30] or it["kind"]
    ext = ".mp4" if it["kind"] == "video" else (Path(urllib.parse.urlparse(it["download"]).path).suffix or ".jpg")
    dest = jd / "raw" / "stock" / f"pixabay-{it['id']}-{words}{ext}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.is_file():
        _download(it["download"], dest)
    line = f"{dest.name} — Pixabay {it['kind']} by {it['user']}, {it['page']} (Pixabay Content License)"
    log = jd / "work" / "stock-sources.txt"
    log.parent.mkdir(exist_ok=True)
    if line not in (log.read_text(encoding="utf-8") if log.is_file() else ""):
        with log.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    print(dest)
    print(f"Logged in {log}")


# ---------------------------------------------------------------- finalize
def cmd_finalize(a):
    src = Path(a.rendered)
    if not src.is_file() or src.stat().st_size == 0:
        sys.exit(f"FAIL: {src} is missing or empty")
    p = probe(src)
    if not p["video"]:
        sys.exit(f"FAIL: no video stream in {src}")
    if a.expect_seconds is not None and abs(p["duration"] - a.expect_seconds) > 0.5:
        sys.exit(f"FAIL: duration {p['duration']:.2f}s, expected {a.expect_seconds}s")
    outdir = ROOT / "outputs"
    outdir.mkdir(exist_ok=True)
    dest = outdir / f"{a.job}.final.mp4"
    shutil.copy2(src, dest)
    downloads = Path.home() / "Downloads"
    if downloads.is_dir():
        shutil.copy2(dest, downloads / dest.name)
    if a.srt and Path(a.srt).is_file():
        shutil.copy2(a.srt, outdir / f"{a.job}.final.srt")
        if downloads.is_dir():
            shutil.copy2(a.srt, downloads / f"{a.job}.final.srt")
    credits = ROOT / "projects" / a.job / "work" / "music-credits.txt"
    if credits.is_file():
        shutil.copy2(credits, outdir / f"{a.job}.credits.txt")
        if downloads.is_dir():
            shutil.copy2(credits, downloads / f"{a.job}.credits.txt")
    # Post copy (Instagram/TikTok caption, YouTube title + description): work/post.md travels
    # next to every copy of the video under the same name, <job>.final.md.
    post = ROOT / "projects" / a.job / "work" / "post.md"
    if not post.is_file():
        sys.exit(f"FAIL: {post} is missing — write the post copy before finalizing (see /finish)")
    places = [outdir] + ([downloads] if downloads.is_dir() else [])
    for extra in a.to or []:
        d = Path(extra); d.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, d / dest.name)
        places.append(d)
    for d in places:
        shutil.copy2(post, d / f"{a.job}.final.md")
    jobmd = ROOT / "projects" / a.job / "job.md"
    if jobmd.is_file():
        with jobmd.open("a", encoding="utf-8") as fh:
            fh.write(f"\n- Exported {dt.datetime.now():%Y-%m-%d %H:%M} → outputs/{dest.name} "
                     f"({p['duration']:.0f}s, {p['size']}, {p['fps']} fps, video {p['video']}, audio {p['audio'] or 'none'})\n")
    print(f"OK {dest} — {p['duration']:.2f}s, {p['size']}, {p['video']}/{p['audio'] or 'no audio'}"
          + (f" (copy in {downloads})" if downloads.is_dir() else ""))
    print("Post copy " + f"{a.job}.final.md" + " next to the video in: " + ", ".join(str(d) for d in places))
    if credits.is_file():
        print("Music credit to paste in the post description:\n  " + credits.read_text(encoding="utf-8").strip())


# ---------------------------------------------------------------- prune
def cmd_prune(a):
    d = ROOT / "projects" / a.job
    if not d.is_dir():
        sys.exit(f"No job {d}")
    if not (ROOT / "outputs" / f"{a.job}.final.mp4").is_file():
        sys.exit(f"Refusing: {a.job} has no exported final in outputs/")
    targets = [p for ext in ("*.mp4", "*.mov", "*.wav") for p in (d / "work").glob(ext)]
    if (d / "comp" / "renders").is_dir():
        targets.append(d / "comp" / "renders")
    if not targets:
        print("Nothing to prune.")
        return

    def size(p):
        return p.stat().st_size if p.is_file() else sum(x.stat().st_size for x in p.rglob("*") if x.is_file())
    for t in targets:
        print(f"{size(t) / 1e6:8.1f} MB  {t.relative_to(ROOT)}")
    if not a.yes:
        print("Re-run with --yes to delete the above.")
        return
    for t in targets:
        shutil.rmtree(t) if t.is_dir() else t.unlink()
    print("Pruned. (Inside comp/, 'npx hyperframes clean' frees its cache — never delete comp/.hyperframes.)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("new"); p.add_argument("preset"); p.add_argument("slug"); p.add_argument("files", nargs="*")
    p = sp.add_parser("info"); p.add_argument("file")
    p = sp.add_parser("open"); p.add_argument("file")
    p = sp.add_parser("polish"); p.add_argument("input"); p.add_argument("output")
    p.add_argument("--lufs", type=float, default=-16); p.add_argument("--denoise", type=float, default=12)
    p = sp.add_parser("grade"); p.add_argument("input"); p.add_argument("--out")
    p.add_argument("--deliver", action="store_true"); p.add_argument("--grain", type=float, default=0)
    p.add_argument("--sharpen", type=float, default=0); p.add_argument("--saturation", type=float, default=0.95)
    p.add_argument("--black", type=float, default=0.08); p.add_argument("--temp", type=int, default=5600)
    p = sp.add_parser("subs"); p.add_argument("file"); p.add_argument("--samples", type=int, default=36)
    p = sp.add_parser("mask"); p.add_argument("input"); p.add_argument("--band"); p.add_argument("--scan")
    p.add_argument("--mode", choices=("black", "blur", "crop"), default="black")
    p.add_argument("--times"); p.add_argument("--pad", type=int, default=14); p.add_argument("--out")
    p = sp.add_parser("coldopen"); p.add_argument("input")
    p.add_argument("--start", type=float, required=True); p.add_argument("--end", type=float, required=True)
    p.add_argument("--out"); p.add_argument("--words"); p.add_argument("--words-out"); p.add_argument("--flash", action="store_true")
    p = sp.add_parser("cutpoints"); p.add_argument("segments"); p.add_argument("--video")
    p.add_argument("--offset", type=float, default=0.0); p.add_argument("--window", type=float, default=0.3)
    p = sp.add_parser("scenes"); p.add_argument("file"); p.add_argument("--threshold", type=float, default=0.3)
    p.add_argument("--min-len", type=float, default=0.6)
    p = sp.add_parser("config"); p.add_argument("action", choices=("set", "show"))
    p.add_argument("key", nargs="?"); p.add_argument("value", nargs="?")
    p = sp.add_parser("music"); msp = p.add_subparsers(dest="mcmd", required=True)
    q = msp.add_parser("search"); q.add_argument("words", nargs="*"); q.add_argument("--tags")
    q.add_argument("--instrumental", action="store_true"); q.add_argument("--min", type=int, default=30)
    q.add_argument("--max", type=int, default=300); q.add_argument("--speed"); q.add_argument("--limit", type=int, default=8)
    q.add_argument("--allow-nc", action="store_true")
    q = msp.add_parser("open"); q.add_argument("n", type=int)
    q = msp.add_parser("get"); q.add_argument("n", type=int); q.add_argument("--job")
    p = sp.add_parser("stock"); ssp = p.add_subparsers(dest="scmd", required=True)
    q = ssp.add_parser("search"); q.add_argument("words", nargs="+"); q.add_argument("--job", required=True)
    q.add_argument("--photo", action="store_true")
    q.add_argument("--orientation", choices=("horizontal", "vertical")); q.add_argument("--min", type=int, default=3)
    q.add_argument("--max", type=int, default=60); q.add_argument("--limit", type=int, default=12)
    q = ssp.add_parser("open"); q.add_argument("n", type=int); q.add_argument("--job", required=True)
    q = ssp.add_parser("get"); q.add_argument("n", type=int); q.add_argument("--job", required=True)
    p = sp.add_parser("finalize"); p.add_argument("job"); p.add_argument("rendered")
    p.add_argument("--expect-seconds", type=float); p.add_argument("--srt")
    p.add_argument("--to", action="append", help="also copy the video + post .md to this folder (repeatable)")
    p = sp.add_parser("prune"); p.add_argument("job"); p.add_argument("--yes", action="store_true")
    a = ap.parse_args()
    {"new": cmd_new, "info": cmd_info, "open": cmd_open, "polish": cmd_polish, "grade": cmd_grade,
     "subs": cmd_subs, "mask": cmd_mask, "coldopen": cmd_coldopen, "cutpoints": cmd_cutpoints,
     "scenes": cmd_scenes, "config": cmd_config, "music": cmd_music, "stock": cmd_stock,
     "finalize": cmd_finalize, "prune": cmd_prune}[a.cmd](a)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:  # output piped into head/less and closed early
        pass
