﻿"""Download a YouTube video (or audio) from its URL.

Usage:
    python scripts/yt_download.py <url> [<url> ...] [options]
    Saves to inbox/ (in this project) by default; then hand the file to `vid.py new`.

Examples:
    python yt_download.py https://www.youtube.com/watch?v=XXXX
    python yt_download.py <url> --quality 1080
    python yt_download.py <url> --audio            # MP3 only
    python yt_download.py <url> --out "D:\\Clips"
    python yt_download.py <url> --start 00:01:30 --end 00:02:10   # just a section

Requires: yt-dlp (pip install -U yt-dlp) and ffmpeg on PATH.
"""
import argparse
import sys
from pathlib import Path

try:
    from yt_dlp import YoutubeDL
    from yt_dlp.utils import download_range_func, parse_duration
except ImportError:
    sys.exit("yt-dlp is not installed. Run: python -m pip install -U yt-dlp")

DEFAULT_OUT = Path(__file__).resolve().parents[1] / "inbox"


def build_options(args):
    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    opts = {
        "outtmpl": str(out_dir / "%(title)s [%(id)s].%(ext)s"),
        "noplaylist": not args.playlist,
        "restrictfilenames": False,
        "windowsfilenames": True,
    }

    if args.audio:
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [
            {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "0"}
        ]
    else:
        height = f"[height<={args.quality}]" if args.quality else ""
        # Prefer H.264/AAC in MP4 so the file opens in every editor; fall back to best available.
        opts["format"] = (
            f"bv*{height}[vcodec^=avc1]+ba[ext=m4a]/"
            f"bv*{height}+ba/b{height}/b"
        )
        opts["merge_output_format"] = "mp4"

    if args.start or args.end:
        start = parse_duration(args.start) if args.start else 0
        end = parse_duration(args.end) if args.end else float("inf")
        opts["download_ranges"] = download_range_func(None, [(start, end)])
        opts["force_keyframes_at_cuts"] = True

    return opts


def main():
    p = argparse.ArgumentParser(description="Download YouTube videos from their URL.")
    p.add_argument("urls", nargs="*", help="One or more YouTube URLs")
    p.add_argument("-o", "--out", default=str(DEFAULT_OUT), help="Output folder")
    p.add_argument("-q", "--quality", type=int, help="Max height, e.g. 720, 1080, 2160")
    p.add_argument("-a", "--audio", action="store_true", help="Audio only (MP3)")
    p.add_argument("--playlist", action="store_true", help="Download the whole playlist if the URL has one")
    p.add_argument("--start", help="Section start, e.g. 90 or 00:01:30")
    p.add_argument("--end", help="Section end, e.g. 130 or 00:02:10")
    args = p.parse_args()

    urls = args.urls
    if not urls:
        url = input("Paste a YouTube URL: ").strip()
        if not url:
            sys.exit("No URL given.")
        urls = [url]

    with YoutubeDL(build_options(args)) as ydl:
        code = ydl.download(urls)

    print(f"\nSaved to: {Path(args.out).resolve()}")
    sys.exit(code)


if __name__ == "__main__":
    main()
