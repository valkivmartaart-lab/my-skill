#!/usr/bin/env python3
"""Transcript helper for the video editor. Standard library only.

Reads word transcripts as produced by HyperFrames (`transcribe.mjs` or
`npx hyperframes transcribe`): either a list of words or {"words": [...]},
each word {"text"|"word", "start", "end"} in seconds.

  words.py show   <words.json> [--pause 0.6]      readable numbered transcript
  words.py ranges <words.json> "12-18,40-41" [--pad 0.08]
                                                   word-index ranges -> time ranges for --remove
  words.py fix    <words.json> <corrections.json>  fix brand spellings (in place)
  words.py srt    <words.json> <out.srt> [--max-words 7]
"""
import json
import re
import sys

# Windows consoles default to cp1252 when piped; force UTF-8 so ⏸, — and accents print.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass


def load(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    words = data["words"] if isinstance(data, dict) else data
    out = []
    for w in words:
        text = w.get("text", w.get("word", ""))
        out.append({"text": str(text).strip(), "start": float(w["start"]), "end": float(w["end"])})
    return data, words, out


def fmt(t):
    m, s = divmod(t, 60)
    return f"{int(m):02d}:{s:05.2f}"


def opt(args, name, default):
    if name in args:
        i = args.index(name)
        val = args[i + 1]
        del args[i:i + 2]
        return type(default)(val)
    return default


def cmd_show(args):
    pause = opt(args, "--pause", 0.6)
    _, _, words = load(args[0])
    if not words:
        print("(empty transcript)")
        return
    total = words[-1]["end"]
    print(f"# {len(words)} words, {fmt(total)} — format: [index] start text   (pauses >= {pause}s shown as ⏸)")
    line, line_start = [], None
    for i, w in enumerate(words):
        if i > 0:
            gap = w["start"] - words[i - 1]["end"]
            if gap >= pause:
                if line:
                    print(f"{fmt(line_start)}  " + " ".join(line))
                    line = []
                print(f"          ⏸ {gap:.1f}s")
        if not line:
            line_start = w["start"]
        line.append(f"[{i}]{w['text']}")
        if re.search(r"[.!?]$", w["text"]) or len(line) >= 14:
            print(f"{fmt(line_start)}  " + " ".join(line))
            line = []
    if line:
        print(f"{fmt(line_start)}  " + " ".join(line))


def cmd_ranges(args):
    pad = opt(args, "--pad", 0.08)
    _, _, words = load(args[0])
    spans = []
    for part in args[1].split(","):
        part = part.strip()
        if not part:
            continue
        a, _, b = part.partition("-")
        a, b = int(a), int(b or a)
        if not (0 <= a <= b < len(words)):
            sys.exit(f"range {part} is outside 0-{len(words) - 1}")
        # Remove from just after the previous kept word to just before the next kept word,
        # leaving up to `pad` seconds (never more than half the gap) so no kept word is clipped.
        if a > 0:
            prev_end = words[a - 1]["end"]
            start = prev_end + min(pad, max(0.0, words[a]["start"] - prev_end) / 2)
        else:
            start = 0.0
        if b + 1 < len(words):
            next_start = words[b + 1]["start"]
            end = next_start - min(pad, max(0.0, next_start - words[b]["end"]) / 2)
        else:
            end = 99999.0  # to the end of the file; transcript-cut clamps to the duration
        if end > start:
            spans.append((round(start, 3), round(end, 3)))
    print(",".join(f"{s}-{e}" for s, e in spans))


def cmd_fix(args):
    path, corr_path = args[0], args[1]
    data, raw_words, words = load(path)
    with open(corr_path, encoding="utf-8") as f:
        corr = {k.lower(): v for k, v in json.load(f).items() if not k.startswith("_")}
    # Longest phrases first so "clean 3.0" wins over "clean".
    phrases = sorted(corr, key=lambda k: -len(k.split()))
    norm = [w["text"].lower().strip(" ,.!?;:\"()…") for w in words]
    changed = 0
    i = 0
    while i < len(words):
        for ph in phrases:
            toks = ph.split()
            n = len(toks)
            if norm[i:i + n] == toks:
                tail = re.search(r"[^\w]*$", words[i + n - 1]["text"]).group(0)
                lead = re.match(r"^[^\w]*", words[i]["text"]).group(0)
                new = lead + corr[ph] + tail
                raw_words[i]["text" if "text" in raw_words[i] else "word"] = new
                for j in range(i + 1, i + n):
                    raw_words[j]["text" if "text" in raw_words[j] else "word"] = ""
                if n > 1:
                    raw_words[i]["end"] = raw_words[i + n - 1]["end"]
                changed += 1
                i += n - 1
                break
        i += 1
    # Drop words emptied by phrase merges.
    kept = [w for w in raw_words if str(w.get("text", w.get("word", ""))).strip()]
    if isinstance(data, dict):
        data["words"] = kept
        if "text" in data:
            data["text"] = " ".join(str(w.get("text", w.get("word", ""))) for w in kept)
    else:
        data = kept
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print(f"{changed} correction(s) applied to {path}")


def cmd_srt(args):
    max_words = opt(args, "--max-words", 7)
    _, _, words = load(args[0])

    def ts(t):
        h, rem = divmod(t, 3600)
        m, s = divmod(rem, 60)
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(round((s % 1) * 1000)) % 1000:03d}"

    cues, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        gap = words[i + 1]["start"] - w["end"] if i + 1 < len(words) else 99
        if len(cur) >= max_words or gap >= 0.5 or re.search(r"[.!?]$", w["text"]):
            cues.append(cur)
            cur = []
    if cur:
        cues.append(cur)
    with open(args[1], "w", encoding="utf-8") as f:
        for n, c in enumerate(cues, 1):
            f.write(f"{n}\n{ts(c[0]['start'])} --> {ts(c[-1]['end'])}\n{' '.join(w['text'] for w in c)}\n\n")
    print(f"{len(cues)} cues written to {args[1]}")


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in {"show", "ranges", "fix", "srt"}:
        sys.exit(__doc__)
    cmd, args = sys.argv[1], sys.argv[2:]
    {"show": cmd_show, "ranges": cmd_ranges, "fix": cmd_fix, "srt": cmd_srt}[cmd](args)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:  # output piped into head/less and closed early
        pass
