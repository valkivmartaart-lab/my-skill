@echo off
REM Double-click to set up the video editor on Windows.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
pause
