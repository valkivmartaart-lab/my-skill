# Short Video Kit (Claude + HyperFrames)

Two things in one folder, both driven by talking to Claude:

1. **Viral video breakdown.** Paste TikTok, Instagram or YouTube links. Claude downloads them, pulls their stats (views, likes, comments, shares, saves, how far above the account's usual views), cuts them into shots, frames, transcript and on-screen text, and tells you what the hook is and why each video worked. It can turn a winning video into a reusable format template.
2. **Video editor.** Drop in your own footage and get a finished MP4: cut, trim and clean the audio, put the hook first, add graphics, B-roll and captions, add music, export. Formats: course lessons (16:9), short explainers, raw talking clips and UGC/avatar ads (9:16).

## Setup (once, ~10 min)

1. Unzip this folder somewhere permanent, **outside OneDrive/Dropbox sync** (e.g. `C:\Users\<you>\Projects\short-video-kit`). Sync slows renders and can lock files mid-write.
2. **Windows:** double-click **`setup.cmd`**. It installs whatever is missing with winget (Git, FFmpeg, Node.js, Python), yt-dlp, the HyperFrames skills and its headless Chrome. **Mac:** run `./setup.sh` in Terminal (needs [Homebrew](https://brew.sh)).
   - Optional, best English/French transcription for editing (~640 MB): `powershell -ExecutionPolicy Bypass -File setup.ps1 -Parakeet` (Mac: `./setup.sh --parakeet`).
   - Optional, prepare the viral breakdown tools now instead of on first use (~650 MB): add `-Breakdown` (Mac: `--breakdown`).
   - If the skills installer asks which agent: **Claude Code**, project scope.
   - **If Windows blocks `setup.cmd`** (Smart App Control): open the folder in the Claude app (step 3) and say *"Set up this project: install FFmpeg, Node, Python and Git with winget if missing, then yt-dlp and the HyperFrames skills. Run the commands directly, don't launch setup.cmd."*
3. **Restart the Claude app** so it sees the new tools, then open this folder (Claude desktop app → Code tab → open folder, or `claude` in a terminal inside the folder).
4. The first time Claude runs `npx hyperframes`, `ffmpeg` or `python …`, choose "always allow" so later steps run without prompts.
5. Optional: fill in `brand/brand.md` (name, colours, fonts, niche) and drop your logo in `brand/assets/logo.png`.

### Optional keys (stored only in `config.local.json` on your machine, never shared)

| Key | What for | How |
|---|---|---|
| Apify token | Live stats incl. **saves** (TikTok) and Instagram views | [console.apify.com](https://console.apify.com/account/integrations) → API token, then tell Claude *"save my Apify token: …"*. Paid per result (fractions of a cent per post). |
| Jamendo client ID | Free music search | [devportal.jamendo.com](https://devportal.jamendo.com) → create an app → Client ID → *"save my Jamendo client ID: …"* |
| Pixabay key | Stock footage (only when you ask for it) | [pixabay.com/api/docs](https://pixabay.com/api/docs/) → *"save my Pixabay key: …"* |

## Breaking down viral videos

| You say | What happens |
|---|---|
| `break these down: <link> <link>` | Download, stats, verdict (outlier or not), hook, beat map, why it works → `library/analyses/<video>/analysis.md` |
| `what's the hook of <link>?` | Same, with the reply focused on the first 3 seconds |
| `get the stats with Apify` | Adds saves, shares and fresher numbers (needs the Apify token) |
| `cut it into pieces` | One MP4 per shot in `library/analyses/<video>/clips/` |
| `add these to the library as formats` | A reusable format card in `library/formats/` (hook formulas, beat timings, text rules, production notes) |
| `use these to improve the <name> format` | Updates that format card with what the new videos do better |
| `make one in this format` | Hands over to the editor below |

Instagram downloads need you to be logged in to instagram.com in **Firefox** (Chrome cookies can't be read on Windows). Downloaded videos are for study only: don't repost them or reuse their footage or music.

## Editing your own videos

Copy a file's path (File Explorer: select the file, **Shift + right-click → Copy as path**) and talk normally:

| You say | What happens |
|---|---|
| `new short video: "C:\Users\you\Videos\take 1.mp4"` | Job created, old burned-in subtitles detected and covered, take transcribed, bad takes, silences and filler cut, audio cleaned, best hook line copied to the front (you pick from 3). You review `cut.mp4`. |
| `you cut "can" too close` / `remove that sentence at 0:23` | Adjusts the cut |
| `make a ugc ad from these clips: …` | Script + shot list, clips graded to look phone-shot, assembled on a timeline |
| `graphics` | Beat-by-beat plan (cards, B-roll, punch-ins, a few transitions) → you say go → live preview link |
| `add this b-roll: "C:\…\clip.mp4"` | Claude looks at its shots and places them where your words describe them |
| "move this card down", "make it orange", "add the logo" | Edits in the preview (you can also click an element and say "this one") |
| `captions` | Animated captions (9:16) or an .srt file (lessons) |
| `find chill instrumental music` | Jamendo search with licenses; `play 2` to listen, `use 2` to add it |
| `export` | Final render → `outputs/<job>.final.mp4` + `<job>.final.md` (ready-to-paste caption, YouTube title and description) + a copy in Downloads |
| `do it all` | Every step with the defaults; stops once on the preview for your OK |

Each step can be a new chat: the job card (`projects/<job>/job.md`) carries the context.

## What's inside

```
setup.cmd / setup.ps1 / setup.sh   one-time setup (Windows / Mac)
CLAUDE.md                          the pipeline and rules Claude follows
.claude/skills/
  viral-video-breakdown/           download + stats + breakdown (scripts/: fetch.py, vidkit.py, apify_stats.py)
  rough-cut, assemble, graphics, captions, finish   the editing steps
  (hyperframes, hyperframes-cli, media-use, hyperframes-registry are added by setup)
presets/formats.md                 the 4 video formats and their defaults
brand/                             brand.md, caption-corrections.json, assets/
scripts/                           vid.py (jobs, subtitles, hook, cut points, B-roll, music, grade, export),
                                   words.py (transcripts), yt_download.py
projects/  outputs/  music/  inbox/  library/      your work (git-ignored except library/analyses and formats)
```

## Using only the breakdown skill

`.claude/skills/viral-video-breakdown/` is self-contained (it only needs Python and FFmpeg). Copy that folder into `~/.claude/skills/` to use it in any project with Claude Code; its results go to a `viral-library/` folder wherever you are.

## Sharing with a team

Put the folder in a private Git repo (`projects/`, `outputs/`, `music/`, `inbox/`, `library/downloads/` and `config.local.json` are git-ignored). Everyone clones it and runs the setup. Brand, presets, caption corrections, format cards and skill improvements are shared with a commit.

## Credits

Rendering, transcription, captions and media tools: [HyperFrames](https://github.com/heygen-com/hyperframes) by HeyGen (Apache 2.0). Downloads: [yt-dlp](https://github.com/yt-dlp/yt-dlp). Breakdown speech recognition: Whisper via [sherpa-onnx](https://github.com/k2-fsa/sherpa-onnx); on-screen text: [RapidOCR](https://github.com/RapidAI/RapidOCR). Optional stats: [Apify](https://apify.com).
